package com.example.fcmdemo.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.example.fcmdemo.FCMViewModel

private data class BottomTab(
    val label: String,
    val icon: @Composable () -> Unit
)

private val tabs = listOf(
    BottomTab("FCM")         { Icon(Icons.Default.Notifications, contentDescription = "FCM") },
    BottomTab("Crashlytics") { Icon(Icons.Default.Warning,       contentDescription = "Crashlytics") }
)

@Composable
fun FCMDemoApp(viewModel: FCMViewModel) {
    MaterialTheme(colorScheme = darkColorScheme()) {
        var selectedTab by rememberSaveable { mutableIntStateOf(0) }

        Scaffold(
            bottomBar = {
                NavigationBar {
                    tabs.forEachIndexed { index, tab ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick  = { selectedTab = index },
                            icon     = tab.icon,
                            label    = { Text(tab.label) }
                        )
                    }
                }
            }
        ) { _ ->
            when (selectedTab) {
                0    -> FCMScreen(viewModel = viewModel)
                else -> CrashTestScreen()
            }
        }
    }
}
