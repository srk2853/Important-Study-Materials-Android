package com.example.fcmdemo

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

/**
 * Creates notification channels and builds/posts notifications.
 * Call [createChannels] once at app start (idempotent after first call).
 */
class NotificationHelper(private val context: Context) {

    private val manager = context.getSystemService(Context.NOTIFICATION_SERVICE)
            as NotificationManager

    init {
        createChannels()
    }

    // -------------------------------------------------------------------------
    // Channel setup
    // -------------------------------------------------------------------------

    fun createChannels() {
        val channels = listOf(
            NotificationChannel(
                CHANNEL_DEFAULT,
                "General Notifications",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "General Acupick notifications" },

            NotificationChannel(
                CHANNEL_CHAT,
                "Chat Messages",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Real-time chat messages from Acupick"
                enableVibration(true)
            },

            NotificationChannel(
                CHANNEL_ORDER,
                "Order Updates",
                NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "Order status updates from Acupick" }
        )
        channels.forEach { manager.createNotificationChannel(it) }
    }

    // -------------------------------------------------------------------------
    // Show notification
    // -------------------------------------------------------------------------

    /**
     * Builds and posts a notification.
     *
     * @param title     Notification title.
     * @param body      Notification body text.
     * @param dataMap   Optional FCM data payload — extras are attached to the tap intent
     *                  so [MainActivity] can react when the user opens the notification.
     * @param notifId   Stable ID; reuses/updates an existing notification with the same ID.
     * @param channelId Target channel (defaults to [CHANNEL_DEFAULT]).
     */
    fun showNotification(
        title    : String,
        body     : String,
        dataMap  : Map<String, String> = emptyMap(),
        notifId  : Int = 0,
        channelId: String = CHANNEL_DEFAULT
    ) {
        val tapIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            dataMap.forEach { (k, v) -> putExtra(k, v) }
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            notifId,
            tapIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        manager.notify(notifId, notification)
    }

    companion object {
        const val CHANNEL_DEFAULT = "acupick_default"
        const val CHANNEL_CHAT    = "acupick_chat"
        const val CHANNEL_ORDER   = "acupick_order"
    }
}
