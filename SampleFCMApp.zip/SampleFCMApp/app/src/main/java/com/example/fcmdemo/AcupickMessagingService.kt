package com.example.fcmdemo

import android.app.NotificationManager
import android.util.Log
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * AcupickMessagingService — FCM entry point for all push messages from the Acupick backend.
 *
 * Message types handled:
 *   1. Notification-only  → system tray handled by FCM SDK when app is in background;
 *                           onMessageReceived() handles it when app is in foreground.
 *   2. Data-only          → always delivered to onMessageReceived(), fore- and background.
 *   3. Notification + data → background: FCM SDK shows the notification and puts data in
 *                            the Intent extras; foreground: onMessageReceived() is called.
 */
class AcupickMessagingService : FirebaseMessagingService() {

    private val notificationHelper by lazy {
        NotificationHelper(applicationContext)
    }

    // -------------------------------------------------------------------------
    // Token lifecycle
    // -------------------------------------------------------------------------

    /**
     * Called when the FCM registration token is first issued or rotated.
     * Send the token to the Acupick server so it can address pushes to this device.
     */
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(TAG, "New FCM token: $token")
        sendTokenToAcupickServer(token)
        // Broadcast locally so the UI can display the refreshed token immediately.
        FCMTokenManager.updateToken(token)
    }

    // -------------------------------------------------------------------------
    // Message receipt
    // -------------------------------------------------------------------------

    /**
     * Invoked for every FCM message while the app is in the foreground.
     * Also invoked for data-only messages regardless of app state.
     *
     * Background notification-only messages are handled automatically by the
     * FCM SDK and never reach this callback.
     */
    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d(TAG, "From: ${remoteMessage.from}")

        val notificationPayload = remoteMessage.notification
        val dataPayload        = remoteMessage.data

        Log.d(TAG, "Notification payload: $notificationPayload")
        Log.d(TAG, "Data payload        : $dataPayload")

        when {
            // ---- Notification + data (or notification-only) in foreground ----
            notificationPayload != null -> {
                val title = notificationPayload.title ?: dataPayload[KEY_TITLE] ?: "Acupick"
                val body  = notificationPayload.body  ?: dataPayload[KEY_BODY]  ?: ""
                notificationHelper.showNotification(
                    title    = title,
                    body     = body,
                    dataMap  = dataPayload,
                    notifId  = remoteMessage.messageId.hashCode()
                )
            }

            // ---- Data-only message ----------------------------------------
            dataPayload.isNotEmpty() -> {
                handleDataMessage(dataPayload)
            }
        }

        // Broadcast so the in-app UI can react without polling.
        FCMEventBus.dispatchMessage(remoteMessage)
    }

    // -------------------------------------------------------------------------
    // Private helpers
    // -------------------------------------------------------------------------

    private fun handleDataMessage(data: Map<String, String>) {
        val messageType = data[KEY_MESSAGE_TYPE] ?: TYPE_GENERIC

        Log.d(TAG, "Handling data message type=$messageType payload=$data")

        val title = data[KEY_TITLE] ?: "Acupick"
        val body  = data[KEY_BODY]  ?: ""

        when (messageType) {
            TYPE_ORDER_UPDATE -> {
                notificationHelper.showNotification(
                    title   = title,
                    body    = body,
                    dataMap = data,
                    notifId = NOTIF_ID_ORDER
                )
            }
            TYPE_CHAT -> {
                notificationHelper.showNotification(
                    title         = title,
                    body          = body,
                    dataMap       = data,
                    notifId       = NOTIF_ID_CHAT,
                    channelId     = NotificationHelper.CHANNEL_CHAT
                )
            }
            else -> {
                notificationHelper.showNotification(
                    title   = title,
                    body    = body,
                    dataMap = data,
                    notifId = NOTIF_ID_GENERIC
                )
            }
        }
    }

    /** Send the FCM token to the Acupick server so it can target this device. */
    private fun sendTokenToAcupickServer(token: String) {
        // TODO: replace with your actual Retrofit / Ktor call to the Acupick API.
        // Example:
        //   acupickApi.registerDeviceToken(DeviceTokenRequest(token = token))
        Log.d(TAG, "TODO: POST token to Acupick server → $token")
    }

    companion object {
        private const val TAG = "AcupickMsgService"

        // Data payload keys
        const val KEY_TITLE        = "title"
        const val KEY_BODY         = "body"
        const val KEY_MESSAGE_TYPE = "message_type"

        // message_type values
        const val TYPE_ORDER_UPDATE = "order_update"
        const val TYPE_CHAT         = "chat"
        const val TYPE_GENERIC      = "generic"

        // Stable notification IDs (prevents stacking identical update notifications)
        private const val NOTIF_ID_ORDER   = 1001
        private const val NOTIF_ID_CHAT    = 1002
        private const val NOTIF_ID_GENERIC = 1000
    }
}
