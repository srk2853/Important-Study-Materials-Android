package com.example.fcmdemo

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

data class FCMUiState(
    val fcmToken        : String  = "Fetching…",
    val isLoadingToken  : Boolean = true,
    val receivedMessages: List<ReceivedMessage> = emptyList()
)

data class ReceivedMessage(
    val title       : String,
    val body        : String,
    val dataPayload : Map<String, String>,
    val timestampMs : Long = System.currentTimeMillis()
)

class FCMViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(FCMUiState())
    val uiState: StateFlow<FCMUiState> = _uiState.asStateFlow()

    init {
        fetchToken()
        observeTokenRefresh()
        observeIncomingMessages()
    }

    // -------------------------------------------------------------------------
    // Token
    // -------------------------------------------------------------------------

    /** Fetches the current FCM registration token from the Firebase SDK. */
    fun fetchToken() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingToken = true) }
            runCatching {
                FirebaseMessaging.getInstance().token.await()
            }.onSuccess { token ->
                FCMTokenManager.updateToken(token)
                _uiState.update { it.copy(fcmToken = token, isLoadingToken = false) }
            }.onFailure { e ->
                _uiState.update { it.copy(fcmToken = "Error: ${e.message}", isLoadingToken = false) }
            }
        }
    }

    /** Observes token rotations emitted by [AcupickMessagingService.onNewToken]. */
    private fun observeTokenRefresh() {
        viewModelScope.launch {
            FCMTokenManager.tokenFlow.collect { token ->
                if (token != null) {
                    _uiState.update { it.copy(fcmToken = token, isLoadingToken = false) }
                }
            }
        }
    }

    // -------------------------------------------------------------------------
    // Incoming messages
    // -------------------------------------------------------------------------

    /** Collects live FCM messages emitted by [AcupickMessagingService.onMessageReceived]. */
    private fun observeIncomingMessages() {
        viewModelScope.launch {
            FCMEventBus.messageFlow.collect { remoteMessage ->
                appendMessage(remoteMessage)
            }
        }
    }

    private fun appendMessage(remoteMessage: RemoteMessage) {
        val title = remoteMessage.notification?.title
            ?: remoteMessage.data[AcupickMessagingService.KEY_TITLE]
            ?: "(no title)"
        val body = remoteMessage.notification?.body
            ?: remoteMessage.data[AcupickMessagingService.KEY_BODY]
            ?: "(no body)"

        val received = ReceivedMessage(
            title       = title,
            body        = body,
            dataPayload = remoteMessage.data
        )
        _uiState.update { state ->
            state.copy(receivedMessages = listOf(received) + state.receivedMessages)
        }
    }

    fun clearMessages() {
        _uiState.update { it.copy(receivedMessages = emptyList()) }
    }
}
