package com.example.fcmdemo

import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.runBlocking

/**
 * Process-singleton event bus for received FCM messages.
 * [AcupickMessagingService] emits here; the ViewModel collects.
 *
 * SharedFlow with replay=1 so a collector that starts just after a message
 * arrives still receives it.
 */
object FCMEventBus {

    private val _messageFlow = MutableSharedFlow<RemoteMessage>(replay = 1)
    val messageFlow: SharedFlow<RemoteMessage> = _messageFlow.asSharedFlow()

    /** Called from [AcupickMessagingService] — safe to call from any thread. */
    fun dispatchMessage(message: RemoteMessage) {
        runBlocking { _messageFlow.emit(message) }
    }
}
