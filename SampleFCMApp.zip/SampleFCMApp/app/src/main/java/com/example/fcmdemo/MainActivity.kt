package com.example.fcmdemo

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import com.example.fcmdemo.ui.FCMDemoApp

/**
 * Single-activity entry point.
 *
 * Responsibilities:
 *   - Request POST_NOTIFICATIONS permission on Android 13+.
 *   - Handle the tap intent when the user opens a background notification
 *     (extras forwarded from [AcupickMessagingService] via [NotificationHelper]).
 *   - Host the Compose UI.
 */
class MainActivity : ComponentActivity() {

    private val viewModel: FCMViewModel by viewModels()

    // Android 13+ notification permission launcher
    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        Log.d(TAG, "POST_NOTIFICATIONS permission granted=$granted")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()
        handleNotificationTapIntent()

        setContent {
            FCMDemoApp(viewModel = viewModel)
        }
    }

    /**
     * Called when the user taps a notification while the app is in the back stack
     * (launchMode="singleTop" ensures this activity is reused, not recreated).
     */
    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleNotificationTapIntent()
    }

    // -------------------------------------------------------------------------
    // Private helpers
    // -------------------------------------------------------------------------

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED

            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    /** Reads FCM data extras attached by [NotificationHelper] to the tap intent. */
    private fun handleNotificationTapIntent() {
        val extras = intent?.extras ?: return
        if (extras.isEmpty) return

        val title = extras.getString(AcupickMessagingService.KEY_TITLE) ?: return
        val body  = extras.getString(AcupickMessagingService.KEY_BODY)  ?: ""
        val type  = extras.getString(AcupickMessagingService.KEY_MESSAGE_TYPE) ?: ""
        Log.d(TAG, "Notification tapped — title=$title body=$body type=$type")
        // Optionally navigate to a specific screen based on `type`.
    }

    companion object {
        private const val TAG = "MainActivity"
    }
}
