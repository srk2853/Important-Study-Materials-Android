package com.example.fcmdemo.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.fcmdemo.FCMUiState
import com.example.fcmdemo.FCMViewModel
import com.example.fcmdemo.ReceivedMessage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FCMScreen(viewModel: FCMViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    FCMScreenContent(
        uiState    = uiState,
        onRefresh  = viewModel::fetchToken,
        onClear    = viewModel::clearMessages
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FCMScreenContent(
    uiState  : FCMUiState,
    onRefresh: () -> Unit,
    onClear  : () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Acupick FCM Demo") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor    = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                ),
                actions = {
                    IconButton(onClick = onClear) {
                        Icon(
                            imageVector        = Icons.Default.Delete,
                            contentDescription = "Clear messages",
                            tint               = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier            = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Spacer(Modifier.height(8.dp)) }

            item {
                TokenCard(
                    token         = uiState.fcmToken,
                    isLoading     = uiState.isLoadingToken,
                    onRefreshClick = onRefresh
                )
            }

            item {
                SectionHeader(
                    title = "Received Messages (${uiState.receivedMessages.size})"
                )
            }

            if (uiState.receivedMessages.isEmpty()) {
                item {
                    EmptyMessagesCard()
                }
            } else {
                items(uiState.receivedMessages, key = { it.timestampMs }) { msg ->
                    MessageCard(message = msg)
                }
            }

            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

// -------------------------------------------------------------------------
// Sub-components
// -------------------------------------------------------------------------

@Composable
private fun TokenCard(
    token         : String,
    isLoading     : Boolean,
    onRefreshClick: () -> Unit
) {
    Card(
        modifier  = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(4.dp),
        shape     = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier            = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment   = Alignment.CenterVertically
            ) {
                Text(
                    text       = "FCM Registration Token",
                    style      = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                } else {
                    IconButton(onClick = onRefreshClick) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh token")
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            SelectionContainer {
                Text(
                    text       = token,
                    fontSize   = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    maxLines   = 4,
                    overflow   = TextOverflow.Ellipsis,
                    color      = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                )
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text       = title,
        style      = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        modifier   = Modifier.padding(vertical = 4.dp)
    )
}

@Composable
private fun EmptyMessagesCard() {
    Card(
        modifier  = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(1.dp),
        shape     = RoundedCornerShape(12.dp)
    ) {
        Box(
            modifier           = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            contentAlignment   = Alignment.Center
        ) {
            Text(
                text  = "No messages yet.\nSend a push from Firebase Console or Acupick backend.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
        }
    }
}

@Composable
private fun MessageCard(message: ReceivedMessage) {
    val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        .format(Date(message.timestampMs))

    Card(
        modifier  = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(2.dp),
        shape     = RoundedCornerShape(12.dp),
        colors    = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text       = message.title,
                    style      = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    modifier   = Modifier.weight(1f)
                )
                Text(
                    text  = timeStr,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.6f)
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                text  = message.body,
                style = MaterialTheme.typography.bodyMedium
            )
            if (message.dataPayload.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text       = "Data payload",
                    style      = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(4.dp))
                message.dataPayload.forEach { (key, value) ->
                    Row {
                        Text(
                            text      = "$key: ",
                            style     = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace,
                            color     = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text   = value,
                            style  = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------
// Preview
// -------------------------------------------------------------------------

@Preview(showBackground = true, name = "FCM Screen – messages")
@Composable
private fun FCMScreenPreview() {
    MaterialTheme {
        FCMScreenContent(
            uiState = FCMUiState(
                fcmToken = "dGVzdC10b2tlbi1leGFtcGxlLTEyMzQ1Njc4OTAxMjM0NTY3ODk=",
                isLoadingToken = false,
                receivedMessages = listOf(
                    ReceivedMessage(
                        title = "Order #1234 Ready",
                        body  = "Your order is ready for pickup at Store #5.",
                        dataPayload = mapOf(
                            "message_type" to "order_update",
                            "order_id"     to "1234"
                        )
                    ),
                    ReceivedMessage(
                        title = "New Chat Message",
                        body  = "Hi! Your order will be slightly delayed.",
                        dataPayload = mapOf("message_type" to "chat")
                    )
                )
            ),
            onRefresh = {},
            onClear   = {}
        )
    }
}
