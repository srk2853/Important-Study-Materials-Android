package com.example.fcmdemo

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Process-singleton that holds the latest FCM registration token.
 * [AcupickMessagingService.onNewToken] writes here; the UI observes via [tokenFlow].
 */
object FCMTokenManager {

    private val _tokenFlow = MutableStateFlow<String?>(null)
    val tokenFlow: StateFlow<String?> = _tokenFlow.asStateFlow()

    fun updateToken(token: String) {
        _tokenFlow.value = token
    }
}
