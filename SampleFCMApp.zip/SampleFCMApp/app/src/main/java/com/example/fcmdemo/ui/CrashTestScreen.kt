package com.example.fcmdemo.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.google.firebase.crashlytics.FirebaseCrashlytics
import kotlinx.coroutines.launch

/**
 * CrashTestScreen — demonstrates every Crashlytics integration point.
 *
 * Crash types covered:
 *   1. Fatal crash         – throws RuntimeException on the main thread; app terminates,
 *                            Crashlytics uploads the report on next launch.
 *   2. Non-fatal exception – records a caught exception without crashing.
 *   3. Custom log          – attaches a breadcrumb log to the next crash report.
 *   4. Custom key          – attaches structured metadata to the next crash report.
 *   5. User ID             – tags crash reports with an anonymised user identifier.
 *   6. Null-pointer crash  – forces a NullPointerException via Kotlin null-safety bypass.
 *   7. Stack-overflow crash– triggers StackOverflowError via infinite recursion.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CrashTestScreen() {
    val crashlytics    = FirebaseCrashlytics.getInstance()
    val snackbarState  = remember { SnackbarHostState() }
    val scope          = rememberCoroutineScope()

    fun snack(msg: String) = scope.launch { snackbarState.showSnackbar(msg) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Crashlytics Test") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor    = MaterialTheme.colorScheme.errorContainer,
                    titleContentColor = MaterialTheme.colorScheme.onErrorContainer
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarState) }
    ) { padding ->
        LazyColumn(
            modifier            = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Spacer(Modifier.height(8.dp)) }

            // ----------------------------------------------------------------
            // Section 1 – Non-destructive helpers (safe to tap any time)
            // ----------------------------------------------------------------
            item { SectionHeader("Non-destructive helpers") }

            item {
                CrashCard(
                    title       = "Log a breadcrumb",
                    description = "Attaches a custom log message that appears in the " +
                            "\"Logs\" tab of the next crash report. Safe — does not crash.",
                    buttonLabel = "Send log",
                    dangerous   = false,
                    onClick     = {
                        crashlytics.log("CrashTestScreen: breadcrumb logged at ${System.currentTimeMillis()}")
                        snack("Breadcrumb logged ✓")
                    }
                )
            }

            item {
                CrashCard(
                    title       = "Set custom keys",
                    description = "Attaches key/value metadata to the next crash report. " +
                            "Useful for capturing app state at the time of a crash.",
                    buttonLabel = "Set keys",
                    dangerous   = false,
                    onClick     = {
                        crashlytics.setCustomKey("screen",       "crash_test")
                        crashlytics.setCustomKey("environment",  "debug")
                        crashlytics.setCustomKey("feature_flag", "fcm_enabled")
                        crashlytics.setCustomKey("session_id",   System.currentTimeMillis().toString())
                        snack("Custom keys set ✓")
                    }
                )
            }

            item {
                CrashCard(
                    title       = "Set user identifier",
                    description = "Tags subsequent crash reports with an anonymised user ID. " +
                            "Never use PII — use hashed IDs or internal references.",
                    buttonLabel = "Set user ID",
                    dangerous   = false,
                    onClick     = {
                        crashlytics.setUserId("acupick-user-demo-42")
                        snack("User ID set ✓")
                    }
                )
            }

            item {
                CrashCard(
                    title       = "Record non-fatal exception",
                    description = "Reports a caught exception to Crashlytics without " +
                            "crashing the app. Appears as a non-fatal issue in the console.",
                    buttonLabel = "Record exception",
                    dangerous   = false,
                    onClick     = {
                        try {
                            throw IllegalStateException(
                                "Simulated non-fatal: order payload missing required field"
                            )
                        } catch (e: IllegalStateException) {
                            crashlytics.recordException(e)
                            snack("Non-fatal exception recorded ✓")
                        }
                    }
                )
            }

            // ----------------------------------------------------------------
            // Section 2 – Fatal crashes (app will terminate)
            // ----------------------------------------------------------------
            item { Spacer(Modifier.height(4.dp)) }
            item { SectionHeader("Fatal crashes  ⚠  app will terminate") }

            item {
                CrashCard(
                    title       = "Force crash — RuntimeException",
                    description = "Throws a RuntimeException on the main thread. " +
                            "Crashlytics uploads the full stack trace on the next app launch.",
                    buttonLabel = "CRASH NOW",
                    dangerous   = true,
                    onClick     = {
                        // Log context just before crashing so the report is informative.
                        crashlytics.log("About to trigger a test RuntimeException crash")
                        crashlytics.setCustomKey("crash_type", "runtime_exception")
                        throw RuntimeException(
                            "Test crash from Acupick FCM Demo — RuntimeException"
                        )
                    }
                )
            }

            item {
                CrashCard(
                    title       = "Force crash — NullPointerException",
                    description = "Bypasses Kotlin null-safety to force a NullPointerException. " +
                            "Tests that Crashlytics captures JVM-level NPEs.",
                    buttonLabel = "CRASH — NPE",
                    dangerous   = true,
                    onClick     = {
                        crashlytics.log("About to trigger a NullPointerException crash")
                        crashlytics.setCustomKey("crash_type", "npe")
                        @Suppress("UNCHECKED_CAST")
                        val forced: String = null as String   // safe-cast bypass → NPE
                        forced.length                         // unreachable; triggers crash
                    }
                )
            }

            item {
                CrashCard(
                    title       = "Force crash — StackOverflowError",
                    description = "Triggers infinite recursion to produce a StackOverflowError. " +
                            "Demonstrates that Crashlytics captures Error subclasses too.",
                    buttonLabel = "CRASH — SOE",
                    dangerous   = true,
                    onClick     = {
                        crashlytics.log("About to trigger a StackOverflowError crash")
                        crashlytics.setCustomKey("crash_type", "stack_overflow")
                        recurseForever()
                    }
                )
            }

            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

// -------------------------------------------------------------------------
// Helpers
// -------------------------------------------------------------------------

/** Infinite recursion — deliberately causes a StackOverflowError. */
private fun recurseForever(): Int = recurseForever() + 1

@Composable
private fun SectionHeader(title: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (title.contains("Fatal", ignoreCase = true)) {
            Icon(
                imageVector        = Icons.Default.Warning,
                contentDescription = null,
                tint               = MaterialTheme.colorScheme.error,
                modifier           = Modifier.padding(end = 6.dp)
            )
        }
        Text(
            text       = title,
            style      = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color      = if (title.contains("Fatal", ignoreCase = true))
                             MaterialTheme.colorScheme.error
                         else
                             MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun CrashCard(
    title      : String,
    description: String,
    buttonLabel: String,
    dangerous  : Boolean,
    onClick    : () -> Unit
) {
    Card(
        modifier  = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(2.dp),
        shape     = RoundedCornerShape(12.dp),
        colors    = CardDefaults.cardColors(
            containerColor = if (dangerous)
                MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f)
            else
                MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text       = title,
                style      = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text  = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
            Spacer(Modifier.height(12.dp))
            if (dangerous) {
                Button(
                    onClick = onClick,
                    modifier = Modifier.fillMaxWidth(),
                    colors   = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text(buttonLabel, fontWeight = FontWeight.Bold)
                }
            } else {
                OutlinedButton(
                    onClick  = onClick,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(buttonLabel)
                }
            }
        }
    }
}

// -------------------------------------------------------------------------
// Preview
// -------------------------------------------------------------------------

@Preview(showBackground = true, name = "Crash Test Screen")
@Composable
private fun CrashTestScreenPreview() {
    MaterialTheme {
        CrashTestScreen()
    }
}
