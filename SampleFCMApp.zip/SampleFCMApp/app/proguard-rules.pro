# Keep FCM service class names intact so the manifest declaration keeps working.
-keep class com.example.fcmdemo.AcupickMessagingService { *; }

# Firebase Messaging
-keep class com.google.firebase.** { *; }
-dontwarn com.google.firebase.**
