package com.example.coroutinebuilders.examples

import android.util.Log
import kotlinx.coroutines.*

private const val TAG = "SupervisorJob"

/**
 * JOB vs SUPERVISOR JOB — differences, when to use each
 *
 *  Job (default)
 *    → Failure of any child cancels ALL siblings AND the parent.
 *    → Use when tasks form a critical pipeline: if any step fails, abort everything.
 *    → Example: a multi-step database transaction.
 *
 *  SupervisorJob
 *    → Failure of one child is ISOLATED; siblings and parent continue normally.
 *    → Use when tasks are independent and one failure must not kill the others.
 *    → Example: loading several UI sections in parallel (one bad image ≠ blank screen).
 *
 *  supervisorScope { }
 *    → Suspend-function builder equivalent of SupervisorJob.
 *    → Convenient inside existing suspend functions without creating a new CoroutineScope.
 */
suspend fun runSupervisorJobDemo() {

    // ── 1. Regular Job: one child failure cascades to siblings ───────────────
    Log.d(TAG, "── 1. Regular Job — failure cascades ──")
    val jobScope = CoroutineScope(
        Dispatchers.Default + Job() +
        CoroutineExceptionHandler { _, e ->
            Log.d(TAG, "  [JobScope CEH] caught: ${e.message}")
        }
    )

    val jc1 = jobScope.launch {
        delay(200)
        Log.d(TAG, "  jc1: about to throw")
        throw RuntimeException("jc1 failed!")
    }

    val jc2 = jobScope.launch {
        try {
            delay(2000)
            Log.d(TAG, "  jc2: done")      // ← NEVER prints; cancelled because jc1 threw
        } catch (e: CancellationException) {
            Log.d(TAG, "  jc2: cancelled! Reason → a sibling (jc1) failed in a Job scope")
        }
    }

    joinAll(jc1, jc2)   // wait for both to settle
    Log.d(TAG, "  jobScope Job isActive=${jobScope.coroutineContext[Job]?.isActive}")

    // ── 2. SupervisorJob: one child failure is isolated ───────────────────────
    Log.d(TAG, "── 2. SupervisorJob — failure isolated ──")
    val svScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    // With SupervisorJob the handler MUST be on the failing child itself,
    // not only on the scope, because exceptions don't propagate to the supervisor.
    val childExHandler = CoroutineExceptionHandler { _, e ->
        Log.d(TAG, "  [sc1 CEH] caught: ${e.message}")
    }

    val sc1 = svScope.launch(childExHandler) {
        delay(200)
        Log.d(TAG, "  sc1: about to throw")
        throw RuntimeException("sc1 failed!")
    }

    val sc2 = svScope.launch {
        delay(600)
        Log.d(TAG, "  sc2: finished successfully! (sc1 failure was isolated)")  // ← PRINTS
    }

    joinAll(sc1, sc2)
    Log.d(TAG, "  svScope SupervisorJob isActive=${svScope.coroutineContext[Job]?.isActive}")

    // ── 3. supervisorScope { } builder ────────────────────────────────────────
    Log.d(TAG, "── 3. supervisorScope builder ──")
    // supervisorScope inherits the caller's context and adds SupervisorJob semantics.
    // Siblings are NOT cancelled if one child fails, as long as the exception is handled.
    supervisorScope {
        val a = launch(CoroutineExceptionHandler { _, e ->
            Log.d(TAG, "  [a CEH] ${e.message}")
        }) {
            delay(100)
            throw RuntimeException("child-a failed")
        }

        val b = launch {
            delay(500)
            Log.d(TAG, "  child-b completed (supervisorScope kept it alive despite a failing)")  // PRINTS
        }

        joinAll(a, b)
    }

    // ── 4. Side-by-side comparison summary ───────────────────────────────────
    Log.d(TAG, """
|── Summary ──────────────────────────────────────────────────────────
|
|  Scenario                                  Job        SupervisorJob
|  ─────────────────────────────────────     ────────   ─────────────
|  Child A fails                             ✓ handled  ✓ handled
|  Sibling B cancelled after A fails?        YES ✗      NO  ✓
|  Parent Job cancelled after A fails?       YES ✗      NO  ✓
|  Need CoroutineExceptionHandler?           on scope   on each child
|
|  When to use Job          → pipeline (all-or-nothing)
|  When to use SupervisorJob→ independent parallel tasks
    """.trimMargin())

    jobScope.cancel()
    svScope.cancel()
    Log.d(TAG, "Demo complete")
}
