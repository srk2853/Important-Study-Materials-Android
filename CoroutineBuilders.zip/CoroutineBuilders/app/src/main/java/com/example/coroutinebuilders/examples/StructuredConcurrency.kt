package com.example.coroutinebuilders.examples

import android.util.Log
import kotlinx.coroutines.*

private const val TAG = "StructuredConc"

/**
 * STRUCTURED CONCURRENCY
 *
 * Core idea: every coroutine belongs to a scope (a parent). This creates a tree of
 * coroutines with well-defined lifetimes and clear ownership.
 *
 * The three guarantees:
 *  1. A parent WAITS for all its children before it finishes.
 *  2. Cancelling a parent automatically cancels ALL its children.
 *  3. A child failure propagates to its parent (unless SupervisorJob is used).
 *
 * These rules together eliminate "leaked" coroutines — coroutines that keep running
 * after the work that created them is done or cancelled.
 *
 * coroutineScope { } builder:
 *  – Inherits parent's coroutineContext (dispatcher, job, etc.)
 *  – Suspends the caller until ALL launched children inside complete.
 *  – If any child fails, all other children are cancelled and the block throws.
 *  – Does NOT cancel the outer/parent scope on failure (unlike a naked child).
 */
suspend fun runStructuredConcurrencyDemo() {

    // ── 1. coroutineScope { }: parent waits for all children ─────────────────
    Log.d(TAG, "── 1. Parent waits for all children (coroutineScope) ──")
    Log.d(TAG, "  starting coroutineScope block…")
    coroutineScope {
        launch {
            delay(300)
            Log.d(TAG, "  child-A finished (300ms)")
        }
        launch {
            delay(200)
            Log.d(TAG, "  child-B finished (200ms)")
        }
        launch {
            delay(100)
            Log.d(TAG, "  child-C finished (100ms)")
        }
        Log.d(TAG, "  all 3 launched — this line runs BEFORE children finish")
    }
    // Execution only reaches here after ALL three children are done.
    Log.d(TAG, "  after coroutineScope: all children have completed ✓")

    // ── 2. Cancellation flows DOWN the tree ───────────────────────────────────
    Log.d(TAG, "── 2. Cancellation cascades to all children ──")
    val scope = CoroutineScope(Dispatchers.Default)
    val parent = scope.launch {
        launch {
            try { delay(5_000) } catch (e: CancellationException) {
                Log.d(TAG, "  child-1 cancelled ✓")
            }
        }
        launch {
            try { delay(5_000) } catch (e: CancellationException) {
                Log.d(TAG, "  child-2 cancelled ✓")
            }
        }
        launch {
            try { delay(5_000) } catch (e: CancellationException) {
                Log.d(TAG, "  child-3 cancelled ✓")
            }
        }
        delay(5_000)
    }
    delay(150)
    parent.cancel()           // cancels parent → automatically cancels all 3 children
    parent.join()
    Log.d(TAG, "  parent cancelled — all children were cancelled automatically ✓")

    // ── 3. One child failure cancels all siblings ─────────────────────────────
    Log.d(TAG, "── 3. Child failure propagates and cancels siblings ──")
    try {
        coroutineScope {
            launch {
                delay(100)
                Log.d(TAG, "  failing-child: throwing now")
                throw RuntimeException("oops — network error")
            }
            launch {
                try {
                    delay(5_000)
                    Log.d(TAG, "  sibling: done")    // never prints
                } catch (e: CancellationException) {
                    Log.d(TAG, "  sibling: cancelled because failing-child threw!")
                }
            }
        }
    } catch (e: RuntimeException) {
        Log.d(TAG, "  coroutineScope rethrew: ${e.message}")
    }

    // ── 4. Nested scopes: structured tree ─────────────────────────────────────
    Log.d(TAG, "── 4. Nested structured scopes ──")
    coroutineScope {
        // Outer scope waits for this sub-tree to finish
        coroutineScope {
            launch { delay(100); Log.d(TAG, "  nested child-1 done") }
            launch { delay(200); Log.d(TAG, "  nested child-2 done") }
        }
        Log.d(TAG, "  inner coroutineScope done — outer continues")
        launch { delay(50); Log.d(TAG, "  outer sibling done") }
    }
    Log.d(TAG, "  entire nested tree complete")

    // ── 5. GlobalScope — unstructured concurrency (ANTI-PATTERN) ─────────────
    Log.d(TAG, "── 5. GlobalScope — unstructured (avoid in production!) ──")
    // GlobalScope has NO parent. The coroutine has no owner and lives for the
    // entire process lifetime. If the Activity/Fragment is destroyed, this keeps
    // running. There is no automatic cancellation — YOU must manage it.
    val leaked = GlobalScope.launch {
        Log.d(TAG, "  GlobalScope: still running even if caller is destroyed!")
        delay(200)
        Log.d(TAG, "  GlobalScope: finished (we only joined it manually in this demo)")
    }
    leaked.join()   // in real code you often forget to join/cancel → memory leak

    // ── 6. How Android provides structured concurrency ────────────────────────
    Log.d(TAG, "── 6. Android-provided scopes ──")
    Log.d(TAG, """
|  lifecycleScope  (Activity/Fragment)
|    → cancelled automatically when the Lifecycle reaches DESTROYED
|    → safe to update UI from coroutines inside it
|
|  viewModelScope  (ViewModel)
|    → cancelled automatically when ViewModel.onCleared() is called
|    → survives configuration changes (screen rotation) unlike lifecycleScope
|
|  Both are backed by SupervisorJob + Dispatchers.Main.immediate
|  so one failing coroutine does not kill all others in that scope.
    """.trimMargin())

    Log.d(TAG, """
|── Why structured concurrency matters ──────────────────────────────
|
|  Without it (GlobalScope / raw Thread):
|    • Coroutines outlive their owners → memory leaks
|    • Cancellation must be tracked and wired manually
|    • Exceptions are silently swallowed or crash the process
|
|  With it (coroutineScope, lifecycleScope, viewModelScope):
|    • Lifetime is tied to a well-defined owner
|    • Cancellation propagates automatically through the tree
|    • Exceptions surface to the right place automatically
    """.trimMargin())

    scope.cancel()
    Log.d(TAG, "Demo complete")
}
