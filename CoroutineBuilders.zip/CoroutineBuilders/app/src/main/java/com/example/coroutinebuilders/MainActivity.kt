package com.example.coroutinebuilders

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.example.coroutinebuilders.examples.runCustomContextDemo
import com.example.coroutinebuilders.examples.runExceptionHandlingDemo
import com.example.coroutinebuilders.examples.runJobDemo
import com.example.coroutinebuilders.examples.runLaunchVsAsyncDemo
import com.example.coroutinebuilders.examples.runStructuredConcurrencyDemo
import com.example.coroutinebuilders.examples.runSupervisorJobDemo
import com.example.coroutinebuilders.ui.theme.CoroutineBuildersTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CoroutineBuildersTheme {
                var status by remember { mutableStateOf("Tap a demo → watch Logcat (filter by tag)") }
                var running by remember { mutableStateOf(false) }

                Scaffold(modifier = Modifier.fillMaxSize()) { padding ->
                    DemoScreen(
                        status = status,
                        running = running,
                        modifier = Modifier.padding(padding),
                        onRun = { label, block ->
                            if (!running) {
                                running = true
                                status = "Running: $label…"
                                lifecycleScope.launch {
                                    try {
                                        block()
                                        status = "✓ $label — see Logcat for full output"
                                    } catch (e: Exception) {
                                        status = "Error in $label: ${e.message}"
                                    } finally {
                                        running = false
                                    }
                                }
                            }
                        }
                    )
                }
            }
        }
    }
}

private data class Demo(val label: String, val block: suspend () -> Unit)

@Composable
private fun DemoScreen(
    status: String,
    running: Boolean,
    modifier: Modifier = Modifier,
    onRun: (String, suspend () -> Unit) -> Unit,
) {
    val demos = remember {
        listOf(
            Demo("1. launch vs async / await",          ::runLaunchVsAsyncDemo),
            Demo("2. Job (lifecycle & cancellation)",   ::runJobDemo),
            Demo("3. SupervisorJob vs Job",             ::runSupervisorJobDemo),
            Demo("4. Exception Handling",               ::runExceptionHandlingDemo),
            Demo("5. Custom Coroutine Context",         ::runCustomContextDemo),
            Demo("6. Structured Concurrency",           ::runStructuredConcurrencyDemo),
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = "Coroutine Builders Demo",
            style = MaterialTheme.typography.headlineSmall,
            textAlign = TextAlign.Center,
        )

        Text(
            text = status,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.primary,
            textAlign = TextAlign.Center,
        )

        if (running) {
            CircularProgressIndicator()
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

        demos.forEach { demo ->
            Button(
                onClick = { onRun(demo.label, demo.block) },
                enabled = !running,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(demo.label)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Open Logcat and filter by tag to see demo output:\n" +
                    "LaunchVsAsync · JobExample · SupervisorJob\n" +
                    "ExceptionHandling · CustomContext · StructuredConc",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}
