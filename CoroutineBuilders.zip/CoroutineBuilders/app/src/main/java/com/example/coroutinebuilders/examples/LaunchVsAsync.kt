package com.example.coroutinebuilders.examples

import android.util.Log
import kotlinx.coroutines.*

private const val TAG = "LaunchVsAsync"

/**
 * LAUNCH vs ASYNC / AWAIT
 *
 *  launch { }   → fire-and-forget
 *                 returns Job  (no result value)
 *                 uncaught exceptions propagate to the parent scope
 *
 *  async { }    → concurrent computation
 *                 returns Deferred<T>  (a future result)
 *                 call .await() to suspend until the value is ready
 *                 exception is stored and rethrown when .await() is called
 */
suspend fun runLaunchVsAsyncDemo() {
    val scope = CoroutineScope(Dispatchers.Default)

    // ── 1. launch – fire and forget, no return value ──────────────────────────
    Log.d(TAG, "── 1. launch ──")
    val job: Job = scope.launch {
        delay(300)
        Log.d(TAG, "  launch: task finished (nothing to return)")
    }
    Log.d(TAG, "  launch returned immediately; doing other work…")
    job.join()  // suspends caller until the coroutine finishes (no result)
    Log.d(TAG, "  after join: isCompleted=${job.isCompleted}")

    // ── 2. async/await – get a value back ────────────────────────────────────
    Log.d(TAG, "── 2. async / await ──")
    val deferred: Deferred<Int> = scope.async {
        delay(300)
        Log.d(TAG, "  async: computing result…")
        42          // ← this value is wrapped in Deferred<Int>
    }
    Log.d(TAG, "  async started; doing other work while it computes…")
    val result: Int = deferred.await()  // suspends until value is ready
    Log.d(TAG, "  await result = $result")

    // ── 3. parallel execution – the main reason to prefer async ──────────────
    Log.d(TAG, "── 3. parallel with async (both run at the same time) ──")
    val startParallel = System.currentTimeMillis()
    val d1 = scope.async { delay(500); "Data-A" }
    val d2 = scope.async { delay(500); "Data-B" }
    // Both coroutines started before any await() → they run concurrently
    val combined = "${d1.await()} + ${d2.await()}"
    Log.d(TAG, "  results: $combined  in ~${System.currentTimeMillis() - startParallel}ms (NOT 1000ms)")

    // ── 4. sequential – what happens if you await immediately ────────────────
    Log.d(TAG, "── 4. sequential (await right after async – wastes concurrency) ──")
    val startSeq = System.currentTimeMillis()
    val r1 = scope.async { delay(500); "Seq-A" }.await()  // blocks 500ms before starting next
    val r2 = scope.async { delay(500); "Seq-B" }.await()  // another 500ms
    Log.d(TAG, "  results: $r1 + $r2  in ~${System.currentTimeMillis() - startSeq}ms (~1000ms!)")

    // ── 5. async exception is stored, rethrown at await() ────────────────────
    Log.d(TAG, "── 5. async exception surfaced at await() ──")
    val svScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    val failing = svScope.async {
        delay(100)
        throw ArithmeticException("division by zero")
        @Suppress("UNREACHABLE_CODE") 0
    }
    try {
        failing.await()
    } catch (e: ArithmeticException) {
        Log.d(TAG, "  caught from await(): ${e.message}")
    }

    Log.d(TAG, """
|── Summary ──
|  Use launch when you don't need a return value (side-effects, UI updates)
|  Use async  when you need a result or want to run tasks in parallel
    """.trimMargin())

    scope.cancel()
    svScope.cancel()
    Log.d(TAG, "Demo complete — check full output above in Logcat")
}
