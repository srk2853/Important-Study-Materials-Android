package com.example.coroutinebuilders.examples

import android.util.Log
import kotlinx.coroutines.*

private const val TAG = "JobExample"

/**
 * JOB BASICS
 *
 * A Job is a handle to a coroutine's lifecycle.
 *
 * State machine:
 *   New ──► Active ──► Completing ──► Completed
 *              │                          ▲
 *              └──► Cancelling ──► Cancelled
 *
 * Key properties:  isActive  isCompleted  isCancelled
 * Key functions:   start()   join()       cancel()   cancelAndJoin()
 *
 * Parent–child rule: cancelling a parent automatically cancels all its children.
 */
suspend fun runJobDemo() {
    val scope = CoroutineScope(Dispatchers.Default)

    // ── 1. Job lifecycle states ───────────────────────────────────────────────
    Log.d(TAG, "── 1. Job lifecycle ──")
    val job = scope.launch {
        Log.d(TAG, "  inside: isActive=${coroutineContext[Job]?.isActive}")
        delay(400)
        Log.d(TAG, "  inside: completing…")
    }
    // isActive=true immediately after launch
    Log.d(TAG, "  after launch  → isActive=${job.isActive}  isCompleted=${job.isCompleted}")
    job.join()
    // isCompleted=true after join returns
    Log.d(TAG, "  after join    → isActive=${job.isActive}  isCompleted=${job.isCompleted}")

    // ── 2. Lazy start – job starts only when explicitly started ───────────────
    Log.d(TAG, "── 2. Lazy start ──")
    val lazyJob = scope.launch(start = CoroutineStart.LAZY) {
        Log.d(TAG, "  lazyJob: running now")
        delay(100)
    }
    Log.d(TAG, "  lazyJob created but not running yet: isActive=${lazyJob.isActive}")
    lazyJob.start()   // or lazyJob.join() also starts it
    Log.d(TAG, "  lazyJob started: isActive=${lazyJob.isActive}")
    lazyJob.join()

    // ── 3. Cancellation with cleanup ─────────────────────────────────────────
    Log.d(TAG, "── 3. Cancellation ──")
    val longTask = scope.launch {
        try {
            repeat(20) { i ->
                ensureActive()              // throws CancellationException if cancelled
                Log.d(TAG, "  step $i")
                delay(100)                  // delay() is also cancellable
            }
        } catch (e: CancellationException) {
            Log.d(TAG, "  caught CancellationException: '${e.message}'")
            // always re-throw or let it propagate so the coroutine truly stops
        } finally {
            // finally always runs – use it for cleanup (close streams, release locks)
            Log.d(TAG, "  finally: releasing resources")
        }
    }
    delay(250)
    longTask.cancel("user pressed stop")
    longTask.join()   // wait until cleanup (finally) is done
    Log.d(TAG, "  isCancelled=${longTask.isCancelled}")

    // ── 4. cancelAndJoin – shorthand ─────────────────────────────────────────
    Log.d(TAG, "── 4. cancelAndJoin ──")
    val j = scope.launch { delay(5000) }
    j.cancelAndJoin()     // cancel() + join() in one call
    Log.d(TAG, "  cancelled: ${j.isCancelled}")

    // ── 5. Parent–child: cancelling parent cancels ALL children ──────────────
    Log.d(TAG, "── 5. Parent–child cancellation ──")
    val parent = scope.launch {
        val child1 = launch {
            try { delay(5000) } catch (e: CancellationException) {
                Log.d(TAG, "  child1 cancelled")
            }
        }
        val child2 = launch {
            try { delay(5000) } catch (e: CancellationException) {
                Log.d(TAG, "  child2 cancelled")
            }
        }
        joinAll(child1, child2)
        Log.d(TAG, "  parent done")   // never reached
    }
    delay(200)
    parent.cancel()     // cascades to child1 and child2 automatically
    parent.join()
    Log.d(TAG, "  parent isCancelled=${parent.isCancelled}")

    // ── 6. Job.invokeOnCompletion callback ────────────────────────────────────
    Log.d(TAG, "── 6. invokeOnCompletion ──")
    val completionJob = scope.launch { delay(200) }
    completionJob.invokeOnCompletion { cause ->
        // cause == null  → completed normally
        // cause != null  → cancelled or failed
        Log.d(TAG, "  invokeOnCompletion: cause=$cause  isCancelled=${completionJob.isCancelled}")
    }
    completionJob.join()

    scope.cancel()
    Log.d(TAG, "Demo complete")
}
