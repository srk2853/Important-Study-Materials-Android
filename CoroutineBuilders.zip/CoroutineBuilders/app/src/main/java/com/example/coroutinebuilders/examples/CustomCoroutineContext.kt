package com.example.coroutinebuilders.examples

import android.util.Log
import kotlinx.coroutines.*
import kotlin.coroutines.CoroutineContext

private const val TAG = "CustomContext"

/**
 * CUSTOM COROUTINE CONTEXT
 *
 * CoroutineContext is an immutable, indexed set of typed elements.
 * Combine elements with `+` (right-hand element wins on key collision).
 *
 *  Element type              | Purpose
 *  ─────────────────────────────────────────────────────────────────
 *  Job / SupervisorJob       | Lifecycle and cancellation
 *  CoroutineDispatcher       | Which thread(s) to run on
 *  CoroutineName             | Debug label (visible in Logcat/debugger)
 *  CoroutineExceptionHandler | Handles uncaught exceptions
 *
 * Built-in dispatchers:
 *  Dispatchers.Main      → Android main/UI thread (do NOT block it)
 *  Dispatchers.IO        → Optimised for blocking I/O (network, disk); large thread pool
 *  Dispatchers.Default   → CPU-bound work (parsing, sorting); thread count = CPU cores
 *  Dispatchers.Unconfined→ Runs on calling thread until first suspension; rarely used
 */
suspend fun runCustomContextDemo() {

    // ── 1. Built-in dispatchers ───────────────────────────────────────────────
    Log.d(TAG, "── 1. Built-in dispatchers ──")

    withContext(Dispatchers.Default) {
        Log.d(TAG, "  Default  → CPU work    thread=${Thread.currentThread().name}")
    }
    withContext(Dispatchers.IO) {
        Log.d(TAG, "  IO       → I/O work    thread=${Thread.currentThread().name}")
    }
    withContext(Dispatchers.Unconfined) {
        Log.d(TAG, "  Unconfined (starts on caller thread) thread=${Thread.currentThread().name}")
        delay(50)
        Log.d(TAG, "  Unconfined (after suspension, resumes on resuming thread) thread=${Thread.currentThread().name}")
    }
    // Dispatchers.Main is only safe on Android main thread — shown as comment:
    // withContext(Dispatchers.Main) { textView.text = "UI update" }

    // ── 2. CoroutineName for debugging ────────────────────────────────────────
    Log.d(TAG, "── 2. CoroutineName ──")
    withContext(CoroutineName("FetchUserProfile")) {
        Log.d(TAG, "  running as: ${coroutineContext[CoroutineName]?.name}")
        // Name shows up in thread name in debug mode:  DefaultDispatcher-worker-1 @FetchUserProfile#1
    }

    // ── 3. Combining context elements with + ─────────────────────────────────
    Log.d(TAG, "── 3. Combining context elements ──")
    val exceptionHandler = CoroutineExceptionHandler { ctx, e ->
        Log.d(TAG, "  [Handler] name=${ctx[CoroutineName]?.name}  ex=${e.message}")
    }

    // Build a complete context: dispatcher + name + exception handler
    val customContext: CoroutineContext =
        Dispatchers.IO + CoroutineName("BackgroundWork") + exceptionHandler

    val customScope = CoroutineScope(customContext + SupervisorJob())

    customScope.launch {
        Log.d(TAG, "  thread=${Thread.currentThread().name}")
        Log.d(TAG, "  name  =${coroutineContext[CoroutineName]?.name}")
    }.join()

    // ── 4. Inheriting and overriding context ─────────────────────────────────
    Log.d(TAG, "── 4. Child inherits context, override with + ──")
    customScope.launch(CoroutineName("ChildOverride") + Dispatchers.Default) {
        // Dispatcher and name overridden for this child; SupervisorJob still inherited
        Log.d(TAG, "  child thread=${Thread.currentThread().name}")
        Log.d(TAG, "  child name  =${coroutineContext[CoroutineName]?.name}")
    }.join()

    // ── 5. Switching dispatcher mid-coroutine with withContext ────────────────
    Log.d(TAG, "── 5. Switching dispatcher mid-flight with withContext ──")
    customScope.launch(CoroutineName("NetworkThenProcess")) {
        // Step 1: fetch on IO pool
        val raw = withContext(Dispatchers.IO) {
            Log.d(TAG, "  [IO]      fetching  thread=${Thread.currentThread().name}")
            delay(100)
            "raw json payload"
        }

        delay(100)

        // Step 2: parse on Default (CPU) pool
        val parsed = withContext(Dispatchers.Default) {
            Log.d(TAG, "  [Default] parsing   thread=${Thread.currentThread().name}")
            raw.uppercase()
        }

        // Step 3: update UI → in real app: withContext(Dispatchers.Main) { view.text = parsed }
        Log.d(TAG, "  [IO→Default] result: $parsed")
    }.join()

    // ── 6. Custom CoroutineScope (mirrors ViewModel pattern) ─────────────────
    Log.d(TAG, "── 6. Custom CoroutineScope class ──")
    val appScope = AppCoroutineScope()
    appScope.fetchData()
    delay(300)  // allow background work to finish before cancelling
    appScope.destroy()

    customScope.cancel()
    Log.d(TAG, "Demo complete")
}

/**
 * Demonstrates how to wire a complete, production-ready CoroutineScope.
 * This mirrors the pattern used inside AndroidX ViewModel (viewModelScope).
 */
class AppCoroutineScope : CoroutineScope {

    private val exHandler = CoroutineExceptionHandler { ctx, e ->
        Log.d(TAG, "  [AppScope CEH] name=${ctx[CoroutineName]?.name}  ex=${e.message}")
    }

    // Every element in the context is explicit and purposeful:
    //   SupervisorJob → one task failure does not kill other tasks
    //   Dispatchers.IO → default dispatcher for this scope's work
    //   CoroutineName  → visible in Logcat during debugging
    //   exHandler      → last-resort for uncaught exceptions
    override val coroutineContext: CoroutineContext =
        SupervisorJob() + Dispatchers.IO + CoroutineName("AppScope") + exHandler

    fun fetchData() {
        launch(CoroutineName("FetchData")) {
            Log.d(TAG, "  AppScope.fetchData thread=${Thread.currentThread().name}")
            delay(200)
            Log.d(TAG, "  AppScope.fetchData done")
        }
    }

    fun destroy() {
        Log.d(TAG, "  AppScope.destroy() → cancelling all children")
        coroutineContext[Job]?.cancel()
    }
}
