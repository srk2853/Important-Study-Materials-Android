package com.example.coroutinebuilders.examples

import android.util.Log
import kotlinx.coroutines.*

private const val TAG = "ExceptionHandling"

/**
 * EXCEPTION HANDLING IN COROUTINES
 *
 * Key rules:
 *  1. try-catch inside a coroutine works exactly like normal Kotlin.
 *  2. launch  → uncaught exceptions propagate UP to the parent; use CoroutineExceptionHandler.
 *  3. async   → exceptions are STORED in Deferred and rethrown when .await() is called.
 *  4. Job     → any uncaught child exception cancels ALL siblings + parent hierarchy.
 *  5. SupervisorJob → child exception is isolated; siblings and parent survive.
 *  6. Global  → Thread.setDefaultUncaughtExceptionHandler as a last-resort safety net.
 *
 * CoroutineExceptionHandler (CEH):
 *  - Must be installed on the ROOT coroutine (or its scope) to be effective.
 *  - With Job scope:        put CEH on the scope.
 *  - With SupervisorJob:    put CEH on each individual child launch.
 *  - Does NOT work on nested launch (inner launch exceptions first go to parent launch).
 */
suspend fun runExceptionHandlingDemo() {

    // ── 1. try-catch inside a coroutine ──────────────────────────────────────
    Log.d(TAG, "── 1. try-catch inside coroutine ──")
    val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    scope.launch {
        try {
            throw Ille`galStateException("something went wrong")
        } catch (e: IllegalStateException) {
            Log.d(TAG, "  caught locally: ${e.message}")
        }
    }.join()

    // ── 2. async: exception rethrown at await() ───────────────────────────────
    Log.d(TAG, "── 2. async exception surfaced at await() ──")
    val deferred = scope.async {
        delay(100)
        throw ArithmeticException("division by zero")
        @Suppress("UNREACHABLE_CODE") 0
    }
    try {
        deferred.await()    // exception is stored in Deferred until here
    } catch (e: ArithmeticException) {
        Log.d(TAG, "  await() rethrew: ${e.message}")
    }

    // ── 3. CoroutineExceptionHandler with regular Job ─────────────────────────
    Log.d(TAG, "── 3. CoroutineExceptionHandler with Job scope ──")
    // CEH on the scope catches exceptions from root coroutines of that scope.
    val jobCEH = CoroutineExceptionHandler { ctx, e ->
        Log.d(TAG, "  [JobCEH] coroutine=${ctx[CoroutineName]?.name}  ex=${e.message}")
    }
    val jobScope = CoroutineScope(Dispatchers.Default + Job() + jobCEH + CoroutineName("JobScope"))

    val root = jobScope.launch(CoroutineName("root")) {
        // Nested launch: inner exception propagates to 'root', which propagates to jobScope CEH
        launch(CoroutineName("inner")) {
            throw RuntimeException("inner coroutine threw!")
        }
        delay(500)  // gets cancelled when inner throws
    }
    root.join()
    // After root fails, jobScope's underlying Job is cancelled too.
    Log.d(TAG, "  jobScope Job isActive after failure=${jobScope.coroutineContext[Job]?.isActive}")

    // ── 4. Exception handling with SupervisorJob ──────────────────────────────
    Log.d(TAG, "── 4. CoroutineExceptionHandler with SupervisorJob ──")
    // With SupervisorJob, each failing child needs its OWN CEH because exceptions
    // do NOT propagate to the supervisor (the supervisor intentionally ignores them).
    val svScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    val childCEH = CoroutineExceptionHandler { _, e ->
        Log.d(TAG, "  [ChildCEH] caught on failing child: ${e.message}")
    }

    val failing = svScope.launch(childCEH) {    // ← CEH is on THIS child
        throw RuntimeException("sv-child threw!")
    }
    val sibling = svScope.launch {
        delay(400)
        Log.d(TAG, "  sibling: completed normally (supervisor isolated the failure)")  // PRINTS
    }
    joinAll(failing, sibling)

    // ── 5. Exception in launch vs async summary ───────────────────────────────
    Log.d(TAG, "── 5. launch vs async exception propagation ──")
    val svScope2 = CoroutineScope(Dispatchers.Default + SupervisorJob())

    // launch: exception propagates immediately, CEH handles it
    svScope2.launch(CoroutineExceptionHandler { _, e ->
        Log.d(TAG, "  [launch CEH] ${e.message}")
    }) {
        throw RuntimeException("launch exception")
    }.join()

    // async: exception is deferred until await() — can choose WHEN to handle it
    val d = svScope2.async {
        throw RuntimeException("async exception")
        @Suppress("UNREACHABLE_CODE") ""
    }
    delay(100)  // exception already happened in async, but nobody has called await() yet
    try {
        d.await()
    } catch (e: RuntimeException) {
        Log.d(TAG, "  [async await] ${e.message}")
    }

    // ── 6. Global last-resort handler ─────────────────────────────────────────
    Log.d(TAG, "── 6. Global Thread uncaught exception handler ──")
    // This is the absolute last resort – fires for exceptions that escape ALL coroutine handlers.
    // In production Android apps, a crash reporting SDK (e.g. Firebase Crashlytics)
    // installs itself here automatically.
    val original = Thread.getDefaultUncaughtExceptionHandler()
    Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
        Log.d(TAG, "  [Global] uncaught on thread '${thread.name}': ${throwable.message}")
        // Always delegate to the original so the system/crash reporter still works
        original?.uncaughtException(thread, throwable)
    }
    Log.d(TAG, "  Global handler set (protects against any uncaught throwable on any thread)")
    Thread.setDefaultUncaughtExceptionHandler(original)   // restore for demo cleanliness

    Log.d(TAG, """
|── Summary ──────────────────────────────────────────────────────────────
|
|                   Job scope                SupervisorJob scope
|  ─────────────   ──────────────────────   ──────────────────────────
|  CEH location    on the SCOPE              on EACH failing CHILD
|  Siblings        cancelled on failure      unaffected on failure
|  try-catch       works anywhere inside     works anywhere inside
|  async           exception at await()      exception at await()
|  Global          Thread.setDefaultUncaughtExceptionHandler (last resort)
    """.trimMargin())

    scope.cancel()
    jobScope.cancel()
    svScope.cancel()
    svScope2.cancel()
    Log.d(TAG, "Demo complete")
}
