package com.example.hiltdemo.di

import android.content.Context
import androidx.room.Room
import com.example.hiltdemo.data.local.AppDatabase
import com.example.hiltdemo.data.local.dao.PostDao
import com.example.hiltdemo.data.local.dao.UserDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Provides Room database and DAO dependencies.
 * @ApplicationContext is a built-in Hilt qualifier for the Application Context —
 * no need to pass it manually.
 */
@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideAppDatabase(@ApplicationContext context: Context): AppDatabase =
        Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            AppDatabase.DATABASE_NAME
        ).fallbackToDestructiveMigration().build()

    /**
     * DAOs are provided from the database instance.
     * They share the @Singleton scope of the database.
     */
    @Provides
    @Singleton
    fun provideUserDao(db: AppDatabase): UserDao = db.userDao()

    @Provides
    @Singleton
    fun providePostDao(db: AppDatabase): PostDao = db.postDao()
}
