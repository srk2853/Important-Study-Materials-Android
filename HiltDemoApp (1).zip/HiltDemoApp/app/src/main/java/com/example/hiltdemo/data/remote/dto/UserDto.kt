package com.example.hiltdemo.data.remote.dto

import com.example.hiltdemo.data.local.entity.UserEntity
import com.example.hiltdemo.domain.model.User
import com.google.gson.annotations.SerializedName

data class UserDto(
    val id: Int,
    val name: String,
    val username: String,
    val email: String,
    val phone: String,
    val website: String,
    val company: CompanyDto,
    val address: AddressDto
)

data class CompanyDto(
    val name: String,
    @SerializedName("catchPhrase") val catchPhrase: String,
    val bs: String
)

data class AddressDto(
    val street: String,
    val suite: String,
    val city: String,
    val zipcode: String
)

fun UserDto.toDomainModel() = User(
    id = id,
    name = name,
    username = username,
    email = email,
    phone = phone,
    website = website,
    company = company.name,
    city = address.city
)

fun UserDto.toEntity() = UserEntity(
    id = id,
    name = name,
    username = username,
    email = email,
    phone = phone,
    website = website,
    company = company.name,
    city = address.city
)
