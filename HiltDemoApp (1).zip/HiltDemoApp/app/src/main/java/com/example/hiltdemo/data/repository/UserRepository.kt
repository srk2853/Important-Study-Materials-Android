package com.example.hiltdemo.data.repository

import com.example.hiltdemo.domain.model.User
import com.example.hiltdemo.util.Resource
import kotlinx.coroutines.flow.Flow

interface UserRepository {
    fun getUsers(forceRefresh: Boolean = false): Flow<Resource<List<User>>>
    suspend fun getUserById(id: Int): Resource<User>
}
