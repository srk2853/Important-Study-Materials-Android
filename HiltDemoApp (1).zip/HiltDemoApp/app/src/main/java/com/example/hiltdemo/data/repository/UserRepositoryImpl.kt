package com.example.hiltdemo.data.repository

import com.example.hiltdemo.data.local.dao.UserDao
import com.example.hiltdemo.data.local.entity.toDomainModel
import com.example.hiltdemo.data.remote.ApiService
import com.example.hiltdemo.data.remote.dto.toDomainModel
import com.example.hiltdemo.data.remote.dto.toEntity
import com.example.hiltdemo.domain.model.User
import com.example.hiltdemo.util.Resource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import retrofit2.Retrofit
import javax.inject.Inject

/**
 * @Inject on the constructor tells Hilt how to create this class.
 * All parameters (ApiService, UserDao) are resolved from the Hilt graph automatically.
 * This is constructor injection — the preferred Hilt pattern.
 */
class UserRepositoryImpl @Inject constructor(
    private val apiService: ApiService,
    private val retrofit: Retrofit,
    private val userDao: UserDao
) : UserRepository {

    override fun getUsers(forceRefresh: Boolean): Flow<Resource<List<User>>> = flow {
        emit(Resource.Loading)

        // first() takes a single snapshot from the Room Flow and completes immediately.
        // collect() on a Room Flow NEVER completes (it watches for DB changes forever),
        // so anything after collect() would be unreachable.
        val cachedUsers = userDao.observeAllUsers().first().map { it.toDomainModel() }

        if (cachedUsers.isNotEmpty() && !forceRefresh) {
            // Cache hit — serve instantly and stop; no network call needed.
            emit(Resource.Success(cachedUsers))
            return@flow
        }

        // Cache is empty OR caller forced a refresh — go to network.
        try {
            val remote = apiService.getUsers()
            userDao.clearUsers()
            userDao.upsertUsers(remote.map { it.toEntity() })
            emit(Resource.Success(remote.map { it.toDomainModel() }))
        } catch (e: Exception) {
            // Network failed — serve stale cache if available, otherwise surface error.
            if (cachedUsers.isNotEmpty()) {
                emit(Resource.Success(cachedUsers))
            } else {
                emit(Resource.Error("Network error and no cached data: ${e.localizedMessage}", e))
            }
        }
    }

    override suspend fun getUserById(id: Int): Resource<User> {
        return try {
            val remote = apiService.getUserById(id)
            userDao.upsertUsers(listOf(remote.toEntity()))
            Resource.Success(remote.toDomainModel())
        } catch (e: Exception) {
            val cached = userDao.getUserById(id)
            if (cached != null) {
                Resource.Success(cached.toDomainModel())
            } else {
                Resource.Error("Failed to fetch user: ${e.localizedMessage}", e)
            }
        }
    }
}
