package com.example.hiltdemo.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.hiltdemo.domain.model.Post

@Entity(tableName = "posts")
data class PostEntity(
    @PrimaryKey val id: Int,
    val userId: Int,
    val title: String,
    val body: String
)

fun PostEntity.toDomainModel() = Post(
    id = id,
    userId = userId,
    title = title,
    body = body
)
