package com.example.hiltdemo.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.hiltdemo.data.local.dao.PostDao
import com.example.hiltdemo.data.local.dao.UserDao
import com.example.hiltdemo.data.local.entity.PostEntity
import com.example.hiltdemo.data.local.entity.UserEntity

@Database(
    entities = [UserEntity::class, PostEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun postDao(): PostDao

    companion object {
        const val DATABASE_NAME = "hilt_demo_db"
    }
}
