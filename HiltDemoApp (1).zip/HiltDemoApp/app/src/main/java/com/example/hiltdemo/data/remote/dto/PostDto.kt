package com.example.hiltdemo.data.remote.dto

import com.example.hiltdemo.data.local.entity.PostEntity
import com.example.hiltdemo.domain.model.Post

data class PostDto(
    val id: Int,
    val userId: Int,
    val title: String,
    val body: String
)

fun PostDto.toDomainModel() = Post(
    id = id,
    userId = userId,
    title = title,
    body = body
)

fun PostDto.toEntity() = PostEntity(
    id = id,
    userId = userId,
    title = title,
    body = body
)
