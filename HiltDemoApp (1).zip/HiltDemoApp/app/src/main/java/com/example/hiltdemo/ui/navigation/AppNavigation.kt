package com.example.hiltdemo.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.hiltdemo.ui.screens.home.HomeScreen
import com.example.hiltdemo.ui.screens.posts.PostListScreen
import com.example.hiltdemo.ui.screens.users.UserDetailScreen
import com.example.hiltdemo.ui.screens.users.UserListScreen

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object UserList : Screen("users")
    data object UserDetail : Screen("users/{userId}") {
        fun createRoute(userId: Int) = "users/$userId"
    }
    data object PostList : Screen("posts")
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = Screen.Home.route) {

        composable(Screen.Home.route) {
            HomeScreen(
                onNavigateToUsers = { navController.navigate(Screen.UserList.route) },
                onNavigateToPosts = { navController.navigate(Screen.PostList.route) }
            )
        }

        composable(Screen.UserList.route) {
            UserListScreen(
                onUserClick = { userId ->
                    navController.navigate(Screen.UserDetail.createRoute(userId))
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.UserDetail.route,
            arguments = listOf(navArgument("userId") { type = NavType.IntType })
        ) {
            UserDetailScreen(onBack = { navController.popBackStack() })
        }

        composable(Screen.PostList.route) {
            PostListScreen(onBack = { navController.popBackStack() })
        }
    }
}
