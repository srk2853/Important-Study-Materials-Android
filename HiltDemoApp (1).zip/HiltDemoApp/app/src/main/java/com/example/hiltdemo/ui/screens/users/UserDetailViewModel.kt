package com.example.hiltdemo.ui.screens.users

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.hiltdemo.data.repository.PostRepository
import com.example.hiltdemo.data.repository.UserRepository
import com.example.hiltdemo.domain.model.Post
import com.example.hiltdemo.domain.model.User
import com.example.hiltdemo.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import javax.inject.Inject

data class UserDetailUiState(
    val user: User? = null,
    val posts: List<Post> = emptyList(),
    val isLoadingUser: Boolean = false,
    val isLoadingPosts: Boolean = false,
    val error: String? = null
)

/**
 * SavedStateHandle is injected automatically by Hilt — no factory needed.
 * It gives access to navigation arguments (userId from the nav back stack).
 */
@HiltViewModel
class UserDetailViewModel @Inject constructor(
    private val userRepository: UserRepository,
    private val postRepository: PostRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val userId: Int = checkNotNull(savedStateHandle["userId"])

    private val _uiState = MutableStateFlow(UserDetailUiState())
    val uiState: StateFlow<UserDetailUiState> = _uiState.asStateFlow()

    init {
        loadUser()
        loadUserPosts()
    }

    private fun loadUser() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoadingUser = true)
            when (val result = userRepository.getUserById(userId)) {
                is Resource.Success -> _uiState.value = _uiState.value.copy(
                    user = result.data, isLoadingUser = false
                )
                is Resource.Error -> _uiState.value = _uiState.value.copy(
                    error = result.message, isLoadingUser = false
                )
                is Resource.Loading -> Unit
            }
        }
    }

    private fun loadUserPosts() {
        postRepository.getPostsByUser(userId)
            .onEach { result ->
                _uiState.value = when (result) {
                    is Resource.Loading -> _uiState.value.copy(isLoadingPosts = true)
                    is Resource.Success -> _uiState.value.copy(posts = result.data, isLoadingPosts = false)
                    is Resource.Error -> _uiState.value.copy(error = result.message, isLoadingPosts = false)
                }
            }
            .launchIn(viewModelScope)
    }
}
