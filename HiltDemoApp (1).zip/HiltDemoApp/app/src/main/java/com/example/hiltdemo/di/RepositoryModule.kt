package com.example.hiltdemo.di

import com.example.hiltdemo.data.repository.PostRepository
import com.example.hiltdemo.data.repository.PostRepositoryImpl
import com.example.hiltdemo.data.repository.UserRepository
import com.example.hiltdemo.data.repository.UserRepositoryImpl
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * @Binds is more efficient than @Provides when binding an interface to its implementation.
 * Hilt generates less code — no factory method body required.
 * The module must be abstract because @Binds methods are abstract.
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindUserRepository(impl: UserRepositoryImpl): UserRepository

    @Binds
    @Singleton
    abstract fun bindPostRepository(impl: PostRepositoryImpl): PostRepository
}
