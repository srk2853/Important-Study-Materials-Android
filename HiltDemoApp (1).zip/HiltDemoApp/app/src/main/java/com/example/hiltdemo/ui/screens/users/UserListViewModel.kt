package com.example.hiltdemo.ui.screens.users

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.hiltdemo.data.repository.UserRepository
import com.example.hiltdemo.domain.model.User
import com.example.hiltdemo.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import javax.inject.Inject

data class UserListUiState(
    val users: List<User> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null
)

/**
 * @HiltViewModel registers this ViewModel with Hilt's ViewModelComponent.
 * It is scoped to the ViewModel lifecycle — destroyed with the ViewModel, not the Activity.
 * Compose retrieves it via hiltViewModel() which routes through the Hilt graph.
 */
@HiltViewModel
class UserListViewModel @Inject constructor(
    private val userRepository: UserRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(UserListUiState())
    val uiState: StateFlow<UserListUiState> = _uiState.asStateFlow()

    init {
        loadUsers()
    }

    fun loadUsers(forceRefresh: Boolean = false) {
        userRepository.getUsers(forceRefresh)
            .onEach { result ->
                _uiState.value = when (result) {
                    is Resource.Loading -> _uiState.value.copy(isLoading = true, error = null)
                    is Resource.Success -> UserListUiState(users = result.data, isLoading = false)
                    is Resource.Error -> _uiState.value.copy(isLoading = false, error = result.message)
                }
            }
            .launchIn(viewModelScope)
    }

    fun refresh() = loadUsers(forceRefresh = true)

    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }
}
