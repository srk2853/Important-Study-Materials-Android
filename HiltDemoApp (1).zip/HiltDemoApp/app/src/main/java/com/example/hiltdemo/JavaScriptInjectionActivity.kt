package com.example.hiltdemo

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.os.Bundle
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import org.json.JSONObject

/**
 * Demonstrates four WebView integration patterns:
 *
 *  1. Embedding & configuring a WebView (WebSettings, WebViewClient, WebChromeClient)
 *  2. Injecting JavaScript from Native into the WebView (evaluateJavascript — 5 methods)
 *  3. Bidirectional event / data exchange (CustomEvent dispatch + @JavascriptInterface callbacks)
 *  4. The Native ↔ WebView bridge (WebToNativeBridge registered via addJavascriptInterface)
 */
class JavaScriptInjectionActivity : ComponentActivity() {

    private lateinit var webView: WebView
    private lateinit var tvNativeLog: TextView
    private lateinit var scrollLog: ScrollView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_javascript_injection)

        webView     = findViewById(R.id.webView)
        tvNativeLog = findViewById(R.id.tvNativeLog)
        scrollLog   = findViewById(R.id.scrollLog)

        setupWebView()       // Use Cases 1 + 4
        loadWebContent()
        setupNativeButtons() // Use Cases 2 + 3
    }

    // ═══════════════════════════════════════════════════════════════════════
    // USE CASE 1 — Embedding a WebView & configuring its settings
    // USE CASE 4 — Registering the Native ↔ WebView bridge
    // ═══════════════════════════════════════════════════════════════════════

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {

        // ── 1a. WebSettings ─────────────────────────────────────────────────
        webView.settings.apply {
            javaScriptEnabled = true                          // required for any JS execution
            domStorageEnabled = true                          // enables localStorage/sessionStorage
            allowFileAccess   = true                          // allows file:// URIs
            mixedContentMode  = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            javaScriptCanOpenWindowsAutomatically = true
        }

        // ── 1b. WebViewClient — intercept navigation & page lifecycle ───────
        webView.webViewClient = object : WebViewClient() {

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                nativeLog("[lifecycle] onPageStarted → $url")
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                nativeLog("[lifecycle] onPageFinished → $url")
                // Use Case 2 — inject the init script the moment the DOM is ready
                injectInitScript(view)
            }
        }

        // ── 1c. WebChromeClient — JS dialogs, console.log, permissions ──────
        webView.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(msg: ConsoleMessage): Boolean {
                nativeLog("[console.${msg.messageLevel().name.lowercase()}] ${msg.message()}")
                return true
            }
        }

        // ── 4a. Register bridge — exposes `window.AndroidBridge` in JS ──────
        webView.addJavascriptInterface(WebToNativeBridge(), "AndroidBridge")
    }

    private fun loadWebContent() {
        // loadDataWithBaseURL keeps a stable origin so CustomEvent and
        // localStorage behave consistently across evaluateJavascript calls.
        webView.loadDataWithBaseURL(
            "https://local.app",
            buildHtmlPage(),
            "text/html",
            "UTF-8",
            null
        )
    }

    // ═══════════════════════════════════════════════════════════════════════
    // USE CASE 2 — Injecting JavaScript from Native into the WebView
    //
    //  Five techniques — each serves a different purpose.
    // ═══════════════════════════════════════════════════════════════════════

    /** Method A — IIFE (Immediately Invoked Function Expression).
     *  Safest pattern: scoped, no global pollution, runs exactly once. */

    private fun injectInitScript(view: WebView) {
        view.evaluateJavascript(
            """
            (function () {
                // Use Case 3 — listen for CustomEvents dispatched by Native
                window.addEventListener('nativeEvent', function (e) {
                    appendLog('native-event', 'nativeEvent ← ' + JSON.stringify(e.detail));
                });
                appendLog('info', 'Init script injected ✓');
            })();
            """.trimIndent(),
            null  // null = no return value needed
        )
    }

    /** Method B — Direct DOM / style manipulation. */
    private fun injectDomScript(view: WebView) {
        view.evaluateJavascript(
            """
            document.body.style.backgroundColor = '#E8F5E9';
            document.getElementById('status').textContent  = 'DOM styled by Native ✓';
            document.getElementById('status').style.color  = '#2E7D32';
            """.trimIndent(),
            null
        )
    }

    /** Method C — Call a named JS function that already exists on the page. */
    private fun callJsFunction(view: WebView, title: String) {
        val safe = title.replace("'", "\\'")
        view.evaluateJavascript("setTitle('$safe');", null)
    }

    /** Method D — Inject an entire script block at runtime (e.g. a feature flag payload). */
    private fun injectScriptBlock(view: WebView, jsCode: String) {
        val escaped = jsCode
            .replace("\\", "\\\\")
            .replace("'", "\\'")
            .replace("\n", "\\n")
        view.evaluateJavascript(
            """
            var s = document.createElement('script');
            s.textContent = '$escaped';
            document.head.appendChild(s);
            """.trimIndent(),
            null
        )
    }

    /** Method E — Read a return value FROM JavaScript.
     *  JS strings come back JSON-encoded ("\"value\"") — strip outer quotes. */
    private fun readJsValue(view: WebView, expression: String, onResult: (String) -> Unit) {
        view.evaluateJavascript(expression) { raw ->
            val clean = raw
                ?.removeSurrounding("\"")
                ?.replace("\\\"", "\"")
                ?.replace("\\n", "\n")
                ?: "null"
            runOnUiThread { onResult(clean) }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // USE CASE 3 — Sending & Receiving Events / Data (both directions)
    //
    //  Native → WebView: evaluateJavascript + window.dispatchEvent(CustomEvent)
    //  WebView → Native: @JavascriptInterface methods in WebToNativeBridge
    // ═══════════════════════════════════════════════════════════════════════

    /** Dispatch a named CustomEvent into the WebView; JS side uses addEventListener. */
    private fun dispatchEventToWebView(eventName: String, payload: JSONObject) {
        val json = payload.toString().replace("'", "\\'")
        webView.evaluateJavascript(
            """
            window.dispatchEvent(new CustomEvent('$eventName', { detail: $json }));
            appendLog('event-out', 'Dispatched "$eventName" from Native');
            """.trimIndent(),
            null
        )
    }

    /** Push a plain data object by calling a named receiver function in the page. */
    private fun pushDataToWebView(data: JSONObject) {
        webView.evaluateJavascript(
            "receiveNativeData(${data});",
            null
        )
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Button wiring — exercises Use Cases 2 and 3 from the native panel
    // ═══════════════════════════════════════════════════════════════════════

    private fun setupNativeButtons() {

        // Inject JS — Use Case 2 (DOM + function call)
        findViewById<Button>(R.id.btnInjectJs).setOnClickListener {
            injectDomScript(webView)
            callJsFunction(webView, "Title Set by Native")
            nativeLog("[native→webview] DOM injection + function call")
        }

        // Send Data — Use Case 3 (data object pushed to page)
        findViewById<Button>(R.id.btnSendData).setOnClickListener {
            val data = JSONObject().apply {
                put("source",    "Native Android")
                put("timestamp", System.currentTimeMillis())
                put("message",   "Hello from Kotlin!")
            }
            pushDataToWebView(data)
            nativeLog("[native→webview] Data pushed")
        }

        // Fire Event — Use Case 3 (CustomEvent dispatched to page)
        findViewById<Button>(R.id.btnFireEvent).setOnClickListener {
            val payload = JSONObject().apply {
                put("type",  "NATIVE_ALERT")
                put("value", System.currentTimeMillis())
            }
            dispatchEventToWebView("nativeEvent", payload)
            nativeLog("[native→webview] Event dispatched: nativeEvent")
        }

        // Get Data — Use Case 2 (evaluateJavascript with return value)
        findViewById<Button>(R.id.btnGetData).setOnClickListener {
            readJsValue(webView, "getWebViewState();") { result ->
                nativeLog("[webview→native] state: $result")
            }
        }

        findViewById<Button>(R.id.btnClearLog).setOnClickListener {
            tvNativeLog.text = "Native Log:"
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // USE CASE 4 — The Native ↔ WebView Bridge
    //
    //  Registered as `window.AndroidBridge` via addJavascriptInterface().
    //  JS calls these methods synchronously; they execute on a BACKGROUND
    //  thread — always dispatch UI work through runOnUiThread {}.
    //  Return values are received synchronously by the JS caller.
    // ═══════════════════════════════════════════════════════════════════════

    private inner class WebToNativeBridge {

        /** Simple one-way message: JS → Android. */
        @JavascriptInterface
        fun postMessage(message: String) {
            runOnUiThread {
                nativeLog("[bridge] postMessage: $message")
                Toast.makeText(this@JavaScriptInjectionActivity, message, Toast.LENGTH_SHORT).show()
            }
        }

        /** Named event with a JSON payload: JS → Android. */
        @JavascriptInterface
        fun sendEvent(eventName: String, jsonPayload: String) {
            runOnUiThread {
                nativeLog("[bridge] event '$eventName': $jsonPayload")
            }
        }

        /** Synchronous getter: JS reads a value FROM Android. */
        @JavascriptInterface
        fun getNativeValue(key: String): String {
            return when (key) {
                "username"   -> "Android User"
                "platform"   -> "Android ${android.os.Build.VERSION.RELEASE}"
                "appVersion" -> "1.0.0"
                else         -> ""
            }
        }

        /** JS triggers Android SharedPreferences storage. */
        @JavascriptInterface
        fun saveToPrefs(key: String, value: String) {
            getSharedPreferences("bridge_prefs", MODE_PRIVATE)
                .edit().putString(key, value).apply()
            runOnUiThread { nativeLog("[bridge] saved: $key = $value") }
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private fun nativeLog(message: String) {
        runOnUiThread {
            tvNativeLog.append("\n$message")
            scrollLog.post { scrollLog.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }

    private fun buildHtmlPage(): String = """
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>WebView Bridge</title>
            <style>
                * { box-sizing: border-box; margin: 0; padding: 0; }
                body { font-family: Arial, sans-serif; background: #F5F5F5; padding: 12px; font-size: 13px; }
                .card { background: #FFF; border-radius: 8px; padding: 12px; margin-bottom: 10px;
                        box-shadow: 0 1px 3px rgba(0,0,0,.12); }
                h2 { color: #1A237E; font-size: 15px; margin-bottom: 6px; }
                h3 { color: #283593; font-size: 12px; margin: 0 0 6px; }
                .label { font-size: 10px; color: #9E9E9E; text-transform: uppercase;
                         letter-spacing: .8px; margin-bottom: 6px; }
                #status { padding: 6px 10px; border-radius: 4px; font-size: 12px;
                          background: #E3F2FD; color: #1565C0; }
                #status.ok  { background: #E8F5E9; color: #2E7D32; }
                #status.err { background: #FFEBEE; color: #C62828; }
                button { background: #3F51B5; color: #FFF; border: none; padding: 7px 12px;
                         border-radius: 4px; font-size: 11px; cursor: pointer; margin: 2px; }
                button:active { background: #283593; }
                button.red  { background: #E53935; }
                button.grey { background: #757575; }
                #data-display { font-size: 11px; background: #F8F9FA; padding: 8px;
                                border-radius: 4px; min-height: 40px; white-space: pre-wrap; word-break: break-all; }
                #event-log { max-height: 110px; overflow-y: auto; }
                .log-entry { padding: 3px 6px; border-left: 3px solid #3F51B5;
                             margin: 2px 0; background: #E8EAF6; font-size: 11px; }
                .log-entry.native-event { border-color: #E53935; background: #FFEBEE; }
                .log-entry.info         { border-color: #43A047; background: #E8F5E9; }
                .log-entry.event-out    { border-color: #FB8C00; background: #FFF3E0; }
            </style>
        </head>
        <body>

        <!-- ── Status card ── -->
        <div class="card">
            <h2>WebView ↔ Native Bridge</h2>
            <div id="status">WebView loaded</div>
        </div>

        <!-- ── USE CASE 4: WebView → Native (bridge calls) ── -->
        <div class="card">
            <h3>WebView → Native (bridge)</h3>
            <div class="label">Calls window.AndroidBridge methods</div>
            <button onclick="sendMessage()">postMessage</button>
            <button onclick="sendEventToNative()">sendEvent</button>
            <button onclick="readNativeValue()">getNativeValue</button>
            <button onclick="savePreference()">saveToPrefs</button>
        </div>

        <!-- ── USE CASE 3: data received from Native ── -->
        <div class="card">
            <h3>Data from Native</h3>
            <div id="data-display">Waiting for native data…</div>
        </div>

        <!-- ── Event log ── -->
        <div class="card">
            <h3>Event Log</h3>
            <div id="event-log">
                <div class="log-entry info">WebView initialized</div>
            </div>
            <button class="grey" onclick="clearLog()" style="margin-top:6px">Clear log</button>
        </div>

        <script>
            // ── USE CASE 4: WebView → Native bridge calls ─────────────────

            function sendMessage() {
                if (window.AndroidBridge) {
                    AndroidBridge.postMessage('Hello from WebView at ' + new Date().toLocaleTimeString());
                    appendLog('info', 'postMessage sent');
                }
            }

            function sendEventToNative() {
                if (window.AndroidBridge) {
                    AndroidBridge.sendEvent('BUTTON_CLICK', JSON.stringify({
                        button: 'sendEvent', ts: Date.now()
                    }));
                    appendLog('info', 'sendEvent fired');
                }
            }

            function readNativeValue() {
                if (window.AndroidBridge) {
                    // Synchronous — return value arrives inline
                    var platform = AndroidBridge.getNativeValue('platform');
                    var user     = AndroidBridge.getNativeValue('username');
                    appendLog('info', 'getNativeValue → ' + user + ' / ' + platform);
                    setStatus('Platform: ' + platform, 'ok');
                }
            }

            function savePreference() {
                if (window.AndroidBridge) {
                    AndroidBridge.saveToPrefs('last_visit', new Date().toISOString());
                    appendLog('info', 'saveToPrefs called');
                }
            }

            // ── USE CASE 3: receive data pushed by Native ─────────────────

            // Called by Native via evaluateJavascript("receiveNativeData({…})")
            function receiveNativeData(data) {
                document.getElementById('data-display').textContent =
                    JSON.stringify(data, null, 2);
                setStatus('Data received from Native ✓', 'ok');
                appendLog('native-event', 'receiveNativeData: ' + JSON.stringify(data));
            }

            // Called by Native via evaluateJavascript("setTitle('…')")
            function setTitle(title) {
                document.querySelector('h2').textContent = title;
            }

            // ── USE CASE 2: return value read by Native ───────────────────

            // Called by Native via evaluateJavascript("getWebViewState()")
            function getWebViewState() {
                return JSON.stringify({
                    title:      document.title,
                    logEntries: document.getElementById('event-log').children.length,
                    innerWidth: window.innerWidth,
                    ts:         Date.now()
                });
            }

            // ── USE CASE 3: CustomEvent dispatched by Native ──────────────

            window.addEventListener('nativeEvent', function (e) {
                appendLog('native-event', 'nativeEvent ← ' + JSON.stringify(e.detail));
                setStatus('CustomEvent received from Native ✓', 'ok');
            });

            // ── Helpers ───────────────────────────────────────────────────

            function appendLog(type, message) {
                var log = document.getElementById('event-log');
                var d   = document.createElement('div');
                d.className = 'log-entry ' + (type || '');
                d.textContent = new Date().toLocaleTimeString() + ': ' + message;
                log.insertBefore(d, log.firstChild);
            }

            function setStatus(msg, cls) {
                var el = document.getElementById('status');
                el.textContent = msg;
                el.className   = cls || '';
            }

            function clearLog() {
                document.getElementById('event-log').innerHTML =
                    '<div class="log-entry info">Log cleared</div>';
            }

            // Notify Native that the JS runtime is ready (Use Case 3)
            window.addEventListener('load', function () {
                if (window.AndroidBridge) {
                    AndroidBridge.sendEvent('PAGE_READY', JSON.stringify({ status: 'ready' }));
                }
            });
        </script>
        </body>
        </html>
    """.trimIndent()

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        webView.removeJavascriptInterface("AndroidBridge")
        webView.destroy()
        super.onDestroy()
    }
}
