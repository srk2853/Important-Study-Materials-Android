package com.example.hiltdemo.ui.screens.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.Article
import androidx.compose.material.icons.filled.Dataset
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onNavigateToUsers: () -> Unit,
    onNavigateToPosts: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Hilt DI Demo", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Hilt Dependency Injection",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Text(
                text = "This app demonstrates Hilt DI patterns with Retrofit networking " +
                        "and Room database across multiple screens.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            HiltConceptCard(
                icon = Icons.Default.Hub,
                title = "@HiltAndroidApp",
                description = "Bootstraps the Hilt component hierarchy from the Application class.",
                code = "@HiltAndroidApp\nclass HiltDemoApp : Application()"
            )

            HiltConceptCard(
                icon = Icons.Default.AccountTree,
                title = "@Module + @InstallIn",
                description = "Declares bindings scoped to a component (e.g. SingletonComponent for app-lifetime objects).",
                code = "@Module\n@InstallIn(SingletonComponent::class)\nobject NetworkModule { ... }"
            )

            HiltConceptCard(
                icon = Icons.Default.Dataset,
                title = "@Binds vs @Provides",
                description = "@Binds binds an interface to its impl with zero boilerplate. @Provides is for types you can't annotate.",
                code = "@Binds\nabstract fun bindUserRepo(\n  impl: UserRepositoryImpl\n): UserRepository"
            )

            HiltConceptCard(
                icon = Icons.Default.Wifi,
                title = "Network (Retrofit + OkHttp)",
                description = "OkHttpClient → Retrofit → ApiService all provided as @Singleton via NetworkModule.",
                code = "@Provides @Singleton\nfun provideApiService(\n  retrofit: Retrofit\n): ApiService"
            )

            HiltConceptCard(
                icon = Icons.Default.Storage,
                title = "Database (Room)",
                description = "AppDatabase and its DAOs are provided via DatabaseModule with @ApplicationContext qualifier.",
                code = "@Provides @Singleton\nfun provideUserDao(\n  db: AppDatabase\n): UserDao"
            )

            HiltConceptCard(
                icon = Icons.Default.Hub,
                title = "@HiltViewModel",
                description = "ViewModels annotated with @HiltViewModel are injected into Compose via hiltViewModel().",
                code = "@HiltViewModel\nclass UserListViewModel @Inject constructor(\n  private val repo: UserRepository\n) : ViewModel()"
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Explore Screens",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = onNavigateToUsers,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.People, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("Users")
                }
                OutlinedButton(
                    onClick = onNavigateToPosts,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Article, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("Posts")
                }
            }
        }
    }
}

@Composable
private fun HiltConceptCard(
    icon: ImageVector,
    title: String,
    description: String,
    code: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                Text(text = title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            }
            Text(text = description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Text(
                    text = code,
                    modifier = Modifier.padding(10.dp),
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
