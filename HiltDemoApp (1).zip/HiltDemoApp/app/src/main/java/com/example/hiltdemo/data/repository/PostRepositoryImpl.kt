package com.example.hiltdemo.data.repository

import com.example.hiltdemo.data.local.dao.PostDao
import com.example.hiltdemo.data.local.entity.toDomainModel
import com.example.hiltdemo.data.remote.ApiService
import com.example.hiltdemo.data.remote.dto.toDomainModel
import com.example.hiltdemo.data.remote.dto.toEntity
import com.example.hiltdemo.domain.model.Post
import com.example.hiltdemo.util.Resource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class PostRepositoryImpl @Inject constructor(
    private val apiService: ApiService,
    private val postDao: PostDao
) : PostRepository {

    override fun getPosts(forceRefresh: Boolean): Flow<Resource<List<Post>>> = flow {
        emit(Resource.Loading)

        // first() takes a single snapshot from the Room Flow and completes immediately.
        // collect() on a Room Flow NEVER completes (it watches for DB changes forever),
        // so anything after collect() would be unreachable.
        val cachedPosts = postDao.observeAllPosts().first().map { it.toDomainModel() }

        if (cachedPosts.isNotEmpty() && !forceRefresh) {
            // Cache hit — serve instantly and stop; no network call needed.
            emit(Resource.Success(cachedPosts))
            return@flow
        }

        // Cache is empty OR caller forced a refresh — go to network.
        try {
            val remote = apiService.getPosts()
            postDao.clearPosts()
            postDao.upsertPosts(remote.map { it.toEntity() })
            emit(Resource.Success(remote.map { it.toDomainModel() }))
        } catch (e: Exception) {
            // Network failed — serve stale cache if available, otherwise surface error.
            if (cachedPosts.isNotEmpty()) {
                emit(Resource.Success(cachedPosts))
            } else {
                emit(Resource.Error("Network error and no cached data: ${e.localizedMessage}", e))
            }
        }
    }

    override fun getPostsByUser(userId: Int): Flow<Resource<List<Post>>> = flow {
        emit(Resource.Loading)
        try {
            val remote = apiService.getPostsByUser(userId)
            postDao.upsertPosts(remote.map { it.toEntity() })
            emit(Resource.Success(remote.map { it.toDomainModel() }))
        } catch (e: Exception) {
            postDao.observePostsByUser(userId)
                .map { it.map { entity -> entity.toDomainModel() } }
                .collect { posts ->
                    if (posts.isNotEmpty()) {
                        emit(Resource.Success(posts))
                    } else {
                        emit(Resource.Error("Failed to load posts: ${e.localizedMessage}", e))
                    }
                }
        }
    }

    override suspend fun getPostById(id: Int): Resource<Post> {
        return try {
            Resource.Success(apiService.getPostById(id).toDomainModel())
        } catch (e: Exception) {
            val cached = postDao.getPostById(id)
            if (cached != null) Resource.Success(cached.toDomainModel())
            else Resource.Error("Failed to fetch post: ${e.localizedMessage}", e)
        }
    }
}
