package com.example.hiltdemo.ui.screens.posts

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.hiltdemo.data.repository.PostRepository
import com.example.hiltdemo.domain.model.Post
import com.example.hiltdemo.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import javax.inject.Inject

data class PostListUiState(
    val posts: List<Post> = emptyList(),
    val filteredPosts: List<Post> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
    val searchQuery: String = ""
)

@HiltViewModel
class PostListViewModel @Inject constructor(
    private val postRepository: PostRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(PostListUiState())
    val uiState: StateFlow<PostListUiState> = _uiState.asStateFlow()

    init {
        loadPosts()
    }

    fun loadPosts(forceRefresh: Boolean = false) {
        postRepository.getPosts(forceRefresh)
            .onEach { result ->
                _uiState.value = when (result) {
                    is Resource.Loading -> _uiState.value.copy(isLoading = true, error = null)
                    is Resource.Success -> {
                        val query = _uiState.value.searchQuery
                        PostListUiState(
                            posts = result.data,
                            filteredPosts = if (query.isBlank()) result.data
                            else result.data.filter {
                                it.title.contains(query, ignoreCase = true) ||
                                        it.body.contains(query, ignoreCase = true)
                            },
                            isLoading = false,
                            searchQuery = query
                        )
                    }

                    is Resource.Error -> _uiState.value.copy(
                        isLoading = false,
                        error = result.message
                    )
                }
            }
            .launchIn(viewModelScope)
    }

    fun onSearchQueryChange(query: String) {
        val posts = _uiState.value.posts
        _uiState.value = _uiState.value.copy(
            searchQuery = query,
            filteredPosts = if (query.isBlank()) posts
            else posts.filter {
                it.title.contains(query, ignoreCase = true) ||
                        it.body.contains(query, ignoreCase = true)
            }
        )
    }

    fun refresh() = loadPosts(forceRefresh = true)
}
