package com.example.hiltdemo.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.hiltdemo.domain.model.User

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: Int,
    val name: String,
    val username: String,
    val email: String,
    val phone: String,
    val website: String,
    val company: String,
    val city: String
)

fun UserEntity.toDomainModel() = User(
    id = id,
    name = name,
    username = username,
    email = email,
    phone = phone,
    website = website,
    company = company,
    city = city
)
