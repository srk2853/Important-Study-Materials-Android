package com.example.hiltdemo.data.repository

import com.example.hiltdemo.domain.model.Post
import com.example.hiltdemo.util.Resource
import kotlinx.coroutines.flow.Flow

interface PostRepository {
    fun getPosts(forceRefresh: Boolean = false): Flow<Resource<List<Post>>>
    fun getPostsByUser(userId: Int): Flow<Resource<List<Post>>>
    suspend fun getPostById(id: Int): Resource<Post>
}
