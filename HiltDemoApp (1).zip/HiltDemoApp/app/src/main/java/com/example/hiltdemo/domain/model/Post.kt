package com.example.hiltdemo.domain.model

data class Post(
    val id: Int,
    val userId: Int,
    val title: String,
    val body: String
)
