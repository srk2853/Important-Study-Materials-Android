package com.example.hiltdemo

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import com.example.hiltdemo.ui.theme.HiltDemoTheme
import java.io.File

// ── Screen-specific palette (teal — distinguishes from plain prefs screen) ───
private val EspTealHeader = Color(0xFF00695C)
private val EspTealButton = Color(0xFF00796B)
private val EspLabelColor = Color(0xFF00695C)
private val EspTermBg     = Color(0xFF263238)
private val EspTermText   = Color(0xFF80CBC4)
private val EspDataBg     = Color(0xFFF8F9FA)
private val EspPageBg     = Color(0xFFE0F2F1)
private val EspInfoBg     = Color(0xFFF1F8E9)
private val EspWarnBg     = Color(0xFFFFF8E1)

// ═════════════════════════════════════════════════════════════════════════
// Activity — entry-point
// ═════════════════════════════════════════════════════════════════════════
class EncryptedSharedPreferenceActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HiltDemoTheme {
                EncryptedSharedPreferenceScreen(onBack = ::finish)
            }
        }
    }
}

// ═════════════════════════════════════════════════════════════════════════
// Root screen composable
// ═════════════════════════════════════════════════════════════════════════
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EncryptedSharedPreferenceScreen(
    modifier: Modifier = Modifier,
    onBack  : () -> Unit = {}
) {
    val context = LocalContext.current

    // ─────────────────────────────────────────────────────────────────────
    // STEP 1 — Create the Master Key (Android Keystore)
    //
    // MasterKeys.AES256_GCM_SPEC is a pre-built KeyGenParameterSpec that:
    //   • Generates a 256-bit AES key
    //   • Uses GCM block mode (authenticated encryption, no separate MAC)
    //   • Stores the key inside the Android Keystore
    //     → On devices with a Secure Enclave (TEE/StrongBox) the raw key
    //       bytes never leave hardware.
    //
    // MasterKeys.getOrCreate(spec)
    //   → Returns the Keystore alias.  Idempotent: creates only once.
    // ─────────────────────────────────────────────────────────────────────
    var initError by remember { mutableStateOf<String?>(null) }

    val encPrefs: SharedPreferences? = remember {
        try {
            // STEP 1: Master Key
            val masterKeyAlias: String = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)

            // ─────────────────────────────────────────────────────────────
            // STEP 2 — Create EncryptedSharedPreferences
            //
            // The returned object implements the same SharedPreferences
            // interface — all read/write calls are identical to plain prefs.
            //
            // Under the hood each put* call:
            //   1. Encrypts the KEY   via AES-256-SIV  (deterministic:
            //      same plaintext key always → same ciphertext, so the
            //      underlying HashMap can still look it up by key)
            //   2. Encrypts the VALUE via AES-256-GCM  (probabilistic:
            //      same value → different ciphertext each time, stronger
            //      security with authenticated integrity check)
            //   3. Persists the ciphertext pair to the XML file
            //
            // Each get* call decrypts transparently — callers see plaintext.
            // ─────────────────────────────────────────────────────────────
            EncryptedSharedPreferences.create(
                "secure_demo_prefs",                   // file name (no .xml ext)
                masterKeyAlias,                        // Keystore alias from Step 1
                context,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            initError = "Initialisation failed: ${e.javaClass.simpleName}: ${e.message}"
            null
        }
    }

    // ── UI state ──────────────────────────────────────────────────────────
    var writeKey     by remember { mutableStateOf("") }
    var writeValue   by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf("String") }
    var readKey      by remember { mutableStateOf("") }
    var readResult   by remember { mutableStateOf("—") }
    var removeKey    by remember { mutableStateOf("") }
    var allData      by remember { mutableStateOf(encPrefs?.let { encDumpAll(it) } ?: "") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text       = "EncryptedSharedPreferences",
                            fontWeight = FontWeight.Bold,
                            fontSize   = 16.sp
                        )
                        Text(
                            text     = "AES-256-SIV keys · AES-256-GCM values",
                            fontSize = 10.sp,
                            color    = Color(0xFFB2DFDB)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector        = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor             = EspTealHeader,
                    titleContentColor          = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->

        // Show a full-screen error if init failed (e.g. Keystore unavailable)
        if (initError != null || encPrefs == null) {
            Box(
                modifier        = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text  = "⚠ ${initError ?: "EncryptedSharedPreferences unavailable"}",
                    color = MaterialTheme.colorScheme.error
                )
            }
            return@Scaffold
        }

        LazyColumn(
            modifier            = modifier
                .fillMaxSize()
                .background(EspPageBg)
                .padding(padding),
            contentPadding      = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {

            // ── Card 0: Security Setup (informational) ──────────────────────
            item {
                EspSectionCard(title = "SECURITY SETUP") {
                    EspInfoBox(
                        text = buildString {
                            appendLine("Master Key Algorithm : AES-256-GCM  (Android Keystore)")
                            appendLine("Key Encryption       : AES-256-SIV  (deterministic AEAD)")
                            appendLine("Value Encryption     : AES-256-GCM  (probabilistic AEAD)")
                            appendLine("Keystore hardware    : TEE / StrongBox on supported devices")
                            append    ("Pref file name       : secure_demo_prefs.xml")
                        },
                        bgColor = EspInfoBg
                    )
                    Spacer(Modifier.height(8.dp))
                    /*
                     * Comparison with plain SharedPreferences
                     * ──────────────────────────────────────────────────────────
                     * Feature             │ SharedPreferences │ EncryptedSharedPreferences
                     * Keys encrypted      │ NO (plaintext XML)│ YES — AES-256-SIV
                     * Values encrypted    │ NO                │ YES — AES-256-GCM
                     * Master key location │ N/A               │ Android Keystore (HW-backed)
                     * API surface         │ SharedPreferences │ Same SharedPreferences API
                     * commit() supported  │ YES               │ NO — use apply() only
                     */
                    EspInfoBox(
                        text = "NOTE: EncryptedSharedPreferences does NOT support\n" +
                               "commit() — always use apply() to persist writes.",
                        bgColor = EspWarnBg
                    )
                }
            }

            // ── Card 1: Write Data ──────────────────────────────────────────
            item {
                EspSectionCard(title = "WRITE DATA  (keys + values are encrypted on disk)") {

                    OutlinedTextField(
                        value         = writeKey,
                        onValueChange = { writeKey = it },
                        label         = { Text("Key  (stored as AES-256-SIV ciphertext)") },
                        singleLine    = true,
                        modifier      = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))

                    OutlinedTextField(
                        value         = writeValue,
                        onValueChange = { writeValue = it },
                        label         = { Text("Value  (stored as AES-256-GCM ciphertext)") },
                        singleLine    = true,
                        modifier      = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))

                    EspTypeDropdown(selected = selectedType, onSelect = { selectedType = it })
                    Spacer(Modifier.height(12.dp))

                    // Only apply() — commit() throws UnsupportedOperationException at runtime
                    Button(
                        onClick = {
                            if (writeKey.isBlank()) { encToast(context, "Key cannot be empty"); return@Button }
                            encBuildEdit(encPrefs, writeKey, writeValue, selectedType).apply()
                            allData = encDumpAll(encPrefs)
                            encToast(context, "Encrypted and saved: $writeKey")
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors   = ButtonDefaults.buttonColors(containerColor = EspTealButton)
                    ) { Text("Encrypt & Save  •  apply()", fontSize = 13.sp) }
                }
            }

            // ── Card 2: Read Data (auto-decrypted) ─────────────────────────
            item {
                EspSectionCard(title = "READ DATA  (auto-decrypted)") {
                    Row(
                        verticalAlignment     = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier              = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value         = readKey,
                            onValueChange = { readKey = it },
                            label         = { Text("Key to read") },
                            singleLine    = true,
                            modifier      = Modifier.weight(1f)
                        )
                        // Decryption is transparent — same get* API as plain prefs
                        Button(
                            onClick = {
                                if (readKey.isBlank()) { encToast(context, "Enter a key"); return@Button }
                                readResult = encReadValue(encPrefs, readKey)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EspTealButton)
                        ) { Text("Read") }
                    }
                    Spacer(Modifier.height(10.dp))
                    EspInfoBox(text = readResult, bgColor = EspDataBg)
                }
            }

            // ── Card 3: Remove / Clear ──────────────────────────────────────
            item {
                EspSectionCard(title = "REMOVE / CLEAR") {
                    OutlinedTextField(
                        value         = removeKey,
                        onValueChange = { removeKey = it },
                        label         = { Text("Key to remove") },
                        singleLine    = true,
                        modifier      = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier              = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = {
                                if (removeKey.isBlank()) { encToast(context, "Enter a key"); return@Button }
                                encPrefs.edit().remove(removeKey).apply()
                                allData = encDumpAll(encPrefs)
                                encToast(context, "Removed: $removeKey")
                            },
                            modifier = Modifier.weight(1f),
                            colors   = ButtonDefaults.buttonColors(containerColor = EspTealButton)
                        ) { Text("Remove Key", fontSize = 12.sp) }

                        androidx.compose.material3.OutlinedButton(
                            onClick = {
                                encPrefs.edit().clear().apply()
                                readResult = "—"
                                allData    = encDumpAll(encPrefs)
                                encToast(context, "All encrypted preferences cleared")
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("Clear All", fontSize = 12.sp) }
                    }
                }
            }

            // ── Card 4: All Stored Data (decrypted in-memory view) ──────────
            item {
                EspSectionCard(
                    title  = "ALL STORED DATA  (decrypted in-memory view)",
                    action = {
                        IconButton(
                            onClick  = { allData = encDumpAll(encPrefs) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = EspLabelColor)
                        }
                    }
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .background(EspDataBg, MaterialTheme.shapes.small)
                            .padding(8.dp)
                    ) {
                        Text(
                            text     = allData.ifEmpty { "(empty)" },
                            style    = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                            color    = Color(0xFF263238),
                            modifier = Modifier.verticalScroll(rememberScrollState())
                        )
                    }
                }
            }

            // ── Card 5: File Info — the on-disk file is encrypted ───────────
            item {
                EspSectionCard(title = "FILE INFO  (encrypted on disk)") {
                    EspInfoBox(
                        text    = encBuildFileInfo(context),
                        bgColor = EspWarnBg
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text     = "Tip: on a rooted device or emulator, run:\n" +
                                   "adb shell run-as com.example.hiltdemo \\\n" +
                                   "  cat shared_prefs/secure_demo_prefs.xml\n" +
                                   "You will see base64 ciphertext — not plaintext keys/values.",
                        fontSize = 10.sp,
                        color    = Color(0xFF546E7A),
                        fontFamily = FontFamily.Monospace
                    )
                }
                Spacer(Modifier.height(8.dp))   // bottom breathing room
            }
        }
    }
}

// ═════════════════════════════════════════════════════════════════════════
// Private composables (scoped to this file)
// ═════════════════════════════════════════════════════════════════════════

/** Card shell with teal label and optional trailing action. */
@Composable
private fun EspSectionCard(
    title   : String,
    modifier: Modifier = Modifier,
    action  : (@Composable () -> Unit)? = null,
    content : @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier  = modifier.fillMaxWidth(),
        colors    = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier          = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
            ) {
                Text(
                    text          = title,
                    fontSize      = 10.sp,
                    fontWeight    = FontWeight.Bold,
                    color         = EspLabelColor,
                    letterSpacing = 0.8.sp,
                    modifier      = Modifier.weight(1f)
                )
                action?.invoke()
            }
            content()
        }
    }
}

/** Monospace info / data display box with configurable background. */
@Composable
private fun EspInfoBox(
    text    : String,
    bgColor : Color  = EspDataBg,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(bgColor, MaterialTheme.shapes.small)
            .padding(10.dp)
    ) {
        Text(
            text  = text,
            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
            color = Color(0xFF263238),
            lineHeight = 18.sp
        )
    }
}

/** Dropdown for selecting data type — identical logic to SharedPreference screen. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EspTypeDropdown(
    selected : String,
    onSelect : (String) -> Unit,
    modifier : Modifier = Modifier
) {
    val types    = remember { listOf("String", "Int", "Boolean", "Float", "Long", "Set<String>") }
    var expanded by remember { mutableStateOf(false) }

    ExposedDropdownMenuBox(
        expanded         = expanded,
        onExpandedChange = { expanded = !expanded },
        modifier         = modifier.fillMaxWidth()
    ) {
        OutlinedTextField(
            value         = selected,
            onValueChange = {},
            readOnly      = true,
            label         = { Text("Data Type") },
            trailingIcon  = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            colors        = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
            modifier      = Modifier
                .menuAnchor()
                .fillMaxWidth()
        )
        ExposedDropdownMenu(
            expanded         = expanded,
            onDismissRequest = { expanded = false }
        ) {
            types.forEach { type ->
                DropdownMenuItem(
                    text           = { Text(type) },
                    onClick        = { onSelect(type); expanded = false },
                    contentPadding = ExposedDropdownMenuDefaults.ItemContentPadding
                )
            }
        }
    }
}

// ═════════════════════════════════════════════════════════════════════════
// EncryptedSharedPreferences business logic — no Compose dependency
// ═════════════════════════════════════════════════════════════════════════

/**
 * Builds a configured Editor for [key]/[value] of [type].
 * NOTE: EncryptedSharedPreferences does NOT support commit() —
 *       always chain .apply().
 */
private fun encBuildEdit(
    prefs : SharedPreferences,
    key   : String,
    value : String,
    type  : String
): SharedPreferences.Editor = prefs.edit().also { ed ->
    when (type) {
        "Int"         -> ed.putInt(key, value.toIntOrNull() ?: 0)
        "Boolean"     -> ed.putBoolean(key, value.trim().lowercase() == "true")
        "Float"       -> ed.putFloat(key, value.toFloatOrNull() ?: 0f)
        "Long"        -> ed.putLong(key, value.toLongOrNull() ?: 0L)
        "Set<String>" -> ed.putStringSet(
            key,
            value.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
        )
        else          -> ed.putString(key, value)
    }
}

/** Reads [key] and returns a formatted type + decrypted-value string. */
private fun encReadValue(prefs: SharedPreferences, key: String): String {
    if (!prefs.contains(key)) return "Key '$key' not found"
    return when (val raw = prefs.all[key]) {
        is String  -> "String       →  \"${prefs.getString(key, "")}\""
        is Int     -> "Int          →  ${prefs.getInt(key, 0)}"
        is Boolean -> "Boolean      →  ${prefs.getBoolean(key, false)}"
        is Float   -> "Float        →  ${prefs.getFloat(key, 0f)}"
        is Long    -> "Long         →  ${prefs.getLong(key, 0L)}"
        is Set<*>  -> "Set<String>  →  ${prefs.getStringSet(key, emptySet())}"
        else       -> "Unknown: ${raw?.javaClass?.simpleName}"
    }
}

/** Returns a sorted dump of all current key-value pairs (decrypted by the library). */
private fun encDumpAll(prefs: SharedPreferences): String {
    val all = prefs.all
    if (all.isEmpty()) return ""
    return all.entries
        .sortedBy { it.key }
        .joinToString("\n") { (k, v) -> "$k = $v  [${v?.javaClass?.simpleName}]" }
}

/**
 * Reads the on-disk XML file and returns path + size + a raw snippet.
 * The snippet shows base64-encoded ciphertext — confirming that neither
 * keys nor values are human-readable in the file.
 */
private fun encBuildFileInfo(context: Context): String {
    val file = File(
        context.filesDir.parent,                    // /data/data/<pkg>
        "shared_prefs/secure_demo_prefs.xml"
    )
    return buildString {
        appendLine("Path : ${file.absolutePath}")
        if (file.exists()) {
            appendLine("Size : ${file.length()} bytes  (encrypted ciphertext)")
            appendLine()
            appendLine("Raw file preview (first 400 chars):")
            append(file.readText().take(400) + "…")
        } else {
            append("(file not yet created — save at least one entry)")
        }
    }
}

private fun encToast(context: Context, msg: String) =
    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
