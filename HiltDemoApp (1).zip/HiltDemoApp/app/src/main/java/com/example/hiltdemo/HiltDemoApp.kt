package com.example.hiltdemo

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * @HiltAndroidApp triggers Hilt's code generation and creates the application-level
 * dependency container. All other Hilt components are scoped to this lifecycle.
 */
@HiltAndroidApp
class HiltDemoApp : Application()
