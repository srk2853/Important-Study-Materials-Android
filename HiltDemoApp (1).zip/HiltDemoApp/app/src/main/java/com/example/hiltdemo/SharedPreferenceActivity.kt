package com.example.hiltdemo

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.hiltdemo.ui.theme.HiltDemoTheme

// ── Screen-specific palette ───────────────────────────────────────────────
private val SpBlueHeader  = Color(0xFF1565C0)
private val SpBlueButton  = Color(0xFF1976D2)
private val SpLabelColor  = Color(0xFF1565C0)
private val SpTermBg      = Color(0xFF263238)
private val SpTermText    = Color(0xFFA5D6A7)
private val SpDataBg      = Color(0xFFF8F9FA)
private val SpPageBg      = Color(0xFFECEFF1)

// ═════════════════════════════════════════════════════════════════════════
// Activity — entry-point, just hosts the Compose tree
// ═════════════════════════════════════════════════════════════════════════
class SharedPreferenceActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HiltDemoTheme {
                SharedPreferenceScreen(onBack = ::finish)
            }
        }
    }
}

// ═════════════════════════════════════════════════════════════════════════
// Root screen composable
// ═════════════════════════════════════════════════════════════════════════
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SharedPreferenceScreen(
    modifier: Modifier = Modifier,
    onBack  : () -> Unit = {}
) {
    val context = LocalContext.current

    // ─────────────────────────────────────────────────────────────────────
    // STEP 1 — Obtain a SharedPreferences instance
    //
    // remember { } creates the instance once and retains it across
    // recompositions (recomposition ≠ Activity recreation).
    //
    // Three ways to get an instance:
    //   1. getSharedPreferences(name, mode)  — named, app-scoped file  ✓
    //   2. getPreferences(mode)              — named after Activity class
    //   3. PreferenceManager.getDefaultSharedPreferences(ctx) — pkg-named
    // ─────────────────────────────────────────────────────────────────────
    val prefs = remember {
        context.getSharedPreferences("demo_shared_prefs", Context.MODE_PRIVATE)
        // File location: /data/data/com.example.hiltdemo/shared_prefs/demo_shared_prefs.xml
        // MODE_PRIVATE is the ONLY safe mode — WORLD_READABLE/WRITABLE are deprecated.
    }

    // ── UI state ──────────────────────────────────────────────────────────
    var writeKey     by remember { mutableStateOf("") }
    var writeValue   by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf("String") }
    var readKey      by remember { mutableStateOf("") }
    var readResult   by remember { mutableStateOf("—") }
    var removeKey    by remember { mutableStateOf("") }
    var allData      by remember { mutableStateOf(spDumpAll(prefs)) }
    var listenerLog  by remember { mutableStateOf("Waiting for changes…") }

    // ─────────────────────────────────────────────────────────────────────
    // STEP 4 — OnSharedPreferenceChangeListener
    //
    // DisposableEffect ties the listener lifetime to this composable:
    //   • Registered when the composable enters the tree.
    //   • Unregistered (via onDispose) when it leaves.
    //
    // IMPORTANT: We hold a strong reference to `listener` — the prefs
    // object stores it in a WeakHashMap, so an inline anonymous object
    // would be immediately garbage-collected and never fire.
    // ─────────────────────────────────────────────────────────────────────
    DisposableEffect(prefs) {
        val listener = SharedPreferences.OnSharedPreferenceChangeListener { p, key ->
            // Runs on the MAIN thread — safe to update Compose state directly
            val newVal = p.all[key]
            val type   = newVal?.javaClass?.simpleName ?: "removed"
            listenerLog += "\n• key='$key'  →  $newVal  [$type]"
            allData      = spDumpAll(p)   // keep "All Data" card in sync
        }
        prefs.registerOnSharedPreferenceChangeListener(listener)
        onDispose { prefs.unregisterOnSharedPreferenceChangeListener(listener) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text       = "SharedPreferences",
                            fontWeight = FontWeight.Bold,
                            fontSize   = 17.sp
                        )
                        Text(
                            text     = "Read · Write · Listen · Clear",
                            fontSize = 11.sp,
                            color    = Color(0xFFBBDEFB)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector        = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor             = SpBlueHeader,
                    titleContentColor          = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier            = modifier
                .fillMaxSize()
                .background(SpPageBg)
                .padding(padding),
            contentPadding      = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {

            // ── Card 1: Write Data ──────────────────────────────────────────
            item {
                SpSectionCard(title = "WRITE DATA") {

                    // Key field
                    OutlinedTextField(
                        value         = writeKey,
                        onValueChange = { writeKey = it },
                        label         = { Text("Key") },
                        placeholder   = { Text("e.g. username") },
                        singleLine    = true,
                        modifier      = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))

                    // Value field
                    OutlinedTextField(
                        value         = writeValue,
                        onValueChange = { writeValue = it },
                        label         = { Text("Value") },
                        placeholder   = { Text("e.g. Alice  /  42  /  true") },
                        singleLine    = true,
                        modifier      = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))

                    // Data-type dropdown (String / Int / Boolean / Float / Long / Set<String>)
                    SpTypeDropdown(selected = selectedType, onSelect = { selectedType = it })
                    Spacer(Modifier.height(12.dp))

                    // ── STEP 2 — apply() vs commit() ───────────────────────
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier              = Modifier.fillMaxWidth()
                    ) {
                        /*
                         * apply()
                         *   • Writes to the in-memory map immediately (reads are consistent)
                         *   • Schedules an async disk flush on a background thread
                         *   • Returns void — no success/failure signal
                         *   • Preferred for all UI-thread writes
                         */
                        Button(
                            onClick = {
                                if (writeKey.isBlank()) { spToast(context, "Key cannot be empty"); return@Button }
                                spBuildEdit(prefs, writeKey, writeValue, selectedType).apply()
                                spToast(context, "Saved with apply()")
                            },
                            modifier = Modifier.weight(1f),
                            colors   = ButtonDefaults.buttonColors(containerColor = SpBlueButton)
                        ) { Text("apply()", fontSize = 12.sp) }

                        /*
                         * commit()
                         *   • Writes to memory AND flushes to disk synchronously
                         *   • Blocks the calling thread until the write completes
                         *   • Returns true on success, false on failure
                         *   • Use only when you need the success result immediately
                         */
                        OutlinedButton(
                            onClick = {
                                if (writeKey.isBlank()) { spToast(context, "Key cannot be empty"); return@OutlinedButton }
                                val ok = spBuildEdit(prefs, writeKey, writeValue, selectedType).commit()
                                allData = spDumpAll(prefs)
                                spToast(context, "commit() returned: $ok")
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("commit()", fontSize = 12.sp) }
                    }
                }
            }

            // ── Card 2: Read Data ───────────────────────────────────────────
            item {
                SpSectionCard(title = "READ DATA") {
                    Row(
                        verticalAlignment     = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier              = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value         = readKey,
                            onValueChange = { readKey = it },
                            label         = { Text("Key to read") },
                            singleLine    = true,
                            modifier      = Modifier.weight(1f)
                        )
                        // STEP 3 — typed getters with default fallbacks
                        Button(
                            onClick = {
                                if (readKey.isBlank()) { spToast(context, "Enter a key"); return@Button }
                                readResult = spReadValue(prefs, readKey)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SpBlueButton)
                        ) { Text("Read") }
                    }
                    Spacer(Modifier.height(10.dp))
                    // Monospace result box
                    SpMonoBox(text = readResult, minLines = 2)
                }
            }

            // ── Card 3: Remove / Clear ──────────────────────────────────────
            item {
                SpSectionCard(title = "REMOVE / CLEAR") {
                    OutlinedTextField(
                        value         = removeKey,
                        onValueChange = { removeKey = it },
                        label         = { Text("Key to remove") },
                        singleLine    = true,
                        modifier      = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier              = Modifier.fillMaxWidth()
                    ) {
                        // editor.remove(key) — deletes a single entry, keep the rest
                        Button(
                            onClick = {
                                if (removeKey.isBlank()) { spToast(context, "Enter a key"); return@Button }
                                prefs.edit().remove(removeKey).apply()
                                spToast(context, "Removed '${removeKey}'")
                            },
                            modifier = Modifier.weight(1f),
                            colors   = ButtonDefaults.buttonColors(containerColor = SpBlueButton)
                        ) { Text("Remove Key", fontSize = 12.sp) }

                        // editor.clear() — wipes the entire file; put*() in same batch runs after clear
                        OutlinedButton(
                            onClick = {
                                prefs.edit().clear().apply()
                                readResult = "—"
                                allData    = spDumpAll(prefs)
                                spToast(context, "All preferences cleared")
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("Clear All", fontSize = 12.sp) }
                    }
                }
            }

            // ── Card 4: All Stored Data ─────────────────────────────────────
            item {
                SpSectionCard(
                    title  = "ALL STORED DATA",
                    action = {
                        IconButton(
                            onClick  = { allData = spDumpAll(prefs) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = SpLabelColor)
                        }
                    }
                ) {
                    // Fixed-height box with independent vertical scroll
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .background(SpDataBg, MaterialTheme.shapes.small)
                            .padding(8.dp)
                    ) {
                        Text(
                            text     = allData.ifEmpty { "(empty)" },
                            style    = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                            color    = Color(0xFF263238),
                            modifier = Modifier.verticalScroll(rememberScrollState())
                        )
                    }
                }
            }

            // ── Card 5: Change Listener ─────────────────────────────────────
            item {
                SpSectionCard(title = "CHANGE LISTENER  (OnSharedPreferenceChangeListener)") {
                    val logScroll = rememberScrollState()
                    // Auto-scroll to latest entry whenever the log string grows
                    LaunchedEffect(listenerLog) { logScroll.animateScrollTo(logScroll.maxValue) }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .background(SpTermBg, MaterialTheme.shapes.small)
                            .padding(10.dp)
                    ) {
                        Text(
                            text     = listenerLog,
                            style    = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                            color    = SpTermText,
                            modifier = Modifier.verticalScroll(logScroll)
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))  // bottom breathing room
            }
        }
    }
}

// ═════════════════════════════════════════════════════════════════════════
// Private composables (scoped to this file)
// ═════════════════════════════════════════════════════════════════════════

/**
 * A white elevated Card with a small uppercase section label at the top.
 * [action] is an optional icon slot aligned to the right of the title row.
 */
@Composable
private fun SpSectionCard(
    title    : String,
    modifier : Modifier = Modifier,
    action   : (@Composable () -> Unit)? = null,
    content  : @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier  = modifier.fillMaxWidth(),
        colors    = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Title row with optional trailing action
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier          = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
            ) {
                Text(
                    text          = title,
                    fontSize      = 10.sp,
                    fontWeight    = FontWeight.Bold,
                    color         = SpLabelColor,
                    letterSpacing = 0.8.sp,
                    modifier      = Modifier.weight(1f)
                )
                action?.invoke()
            }
            content()
        }
    }
}

/**
 * ExposedDropdownMenuBox for selecting the SharedPreferences data type.
 * Supports: String, Int, Boolean, Float, Long, Set<String>
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SpTypeDropdown(
    selected : String,
    onSelect : (String) -> Unit,
    modifier : Modifier = Modifier
) {
    val types    = remember { listOf("String", "Int", "Boolean", "Float", "Long", "Set<String>") }
    var expanded by remember { mutableStateOf(false) }

    ExposedDropdownMenuBox(
        expanded         = expanded,
        onExpandedChange = { expanded = !expanded },
        modifier         = modifier.fillMaxWidth()
    ) {
        OutlinedTextField(
            value         = selected,
            onValueChange = {},
            readOnly      = true,
            label         = { Text("Data Type") },
            trailingIcon  = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            colors        = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
            modifier      = Modifier
                .menuAnchor()   // Ties the TextField to the dropdown popup
                .fillMaxWidth()
        )
        ExposedDropdownMenu(
            expanded         = expanded,
            onDismissRequest = { expanded = false }
        ) {
            types.forEach { type ->
                DropdownMenuItem(
                    text           = { Text(type) },
                    onClick        = { onSelect(type); expanded = false },
                    contentPadding = ExposedDropdownMenuDefaults.ItemContentPadding
                )
            }
        }
    }
}

/** A fixed-height monospace display box with vertical scroll. */
@Composable
private fun SpMonoBox(
    text     : String,
    modifier : Modifier = Modifier,
    minLines : Int      = 1
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(SpDataBg, MaterialTheme.shapes.small)
            .padding(10.dp)
    ) {
        Text(
            text     = text,
            style    = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
            color    = Color(0xFF37474F),
            minLines = minLines
        )
    }
}

// ═════════════════════════════════════════════════════════════════════════
// SharedPreferences business logic — no Compose dependency
// ═════════════════════════════════════════════════════════════════════════

/**
 * STEP 2 — Builds a configured Editor with the correct put* method for [type].
 *
 * Supported types and their storage methods:
 *   String       → putString(key, value)
 *   Int          → putInt(key, value.toInt())
 *   Boolean      → putBoolean(key, value == "true")
 *   Float        → putFloat(key, value.toFloat())
 *   Long         → putLong(key, value.toLong())
 *   Set<String>  → putStringSet(key, commaDelimited.toSet())
 *
 * Caller chains .apply() or .commit() to persist.
 */
private fun spBuildEdit(
    prefs : SharedPreferences,
    key   : String,
    value : String,
    type  : String
): SharedPreferences.Editor = prefs.edit().also { ed ->
    when (type) {
        "Int"         -> ed.putInt(key, value.toIntOrNull() ?: 0)
        "Boolean"     -> ed.putBoolean(key, value.trim().lowercase() == "true")
        "Float"       -> ed.putFloat(key, value.toFloatOrNull() ?: 0f)
        "Long"        -> ed.putLong(key, value.toLongOrNull() ?: 0L)
        "Set<String>" -> ed.putStringSet(
            key,
            value.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
        )
        else          -> ed.putString(key, value)   // "String" — default
    }
}

/**
 * STEP 3 — Reads [key] using the type-safe getter that matches the stored type.
 * Each getter accepts a default that is returned when the key is absent.
 *
 *   getString(key, defValue: String?)
 *   getInt(key, defValue: Int)
 *   getBoolean(key, defValue: Boolean)
 *   getFloat(key, defValue: Float)
 *   getLong(key, defValue: Long)
 *   getStringSet(key, defValues: Set<String>?)
 */
private fun spReadValue(prefs: SharedPreferences, key: String): String {
    if (!prefs.contains(key)) return "Key '$key' not found"
    return when (val raw = prefs.all[key]) {
        is String  -> "String       →  \"${prefs.getString(key, "")}\""
        is Int     -> "Int          →  ${prefs.getInt(key, 0)}"
        is Boolean -> "Boolean      →  ${prefs.getBoolean(key, false)}"
        is Float   -> "Float        →  ${prefs.getFloat(key, 0f)}"
        is Long    -> "Long         →  ${prefs.getLong(key, 0L)}"
        is Set<*>  -> "Set<String>  →  ${prefs.getStringSet(key, emptySet())}"
        else       -> "Unknown: ${raw?.javaClass?.simpleName}"
    }
}

/** Returns a sorted multi-line dump of all current key-value pairs. */
private fun spDumpAll(prefs: SharedPreferences): String {
    val all = prefs.all
    if (all.isEmpty()) return ""
    return all.entries
        .sortedBy { it.key }
        .joinToString("\n") { (k, v) -> "$k = $v  [${v?.javaClass?.simpleName}]" }
}

private fun spToast(context: Context, msg: String) =
    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
